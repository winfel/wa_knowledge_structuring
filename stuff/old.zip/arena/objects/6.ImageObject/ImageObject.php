<?php

$connector->registerCommand('uploadImage',function() use($connector) {
		$id=$connector->getId();
		if (!$id){$connector->error($connector::ERROR_MISSING_ID,'Missing object id');}
		
		$room=$connector->getRoom();
		if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
			
		$file=$_FILES['file'];
		
		if (!$file) {$connector->error($connector::ERROR_MISSING_DATA,'Did not provide a file!');}
		
		$error=$file['error'];
		
		if ($error){
			{$connector->error($connector::ERROR_UPLOAD_FAILED,'Upload failed with code '+$error);}
		} else {
	
			$local=$file['tmp_name'];
			$mime=$file['type'];
			
			$connector->set($room,$id,'content',(file_get_contents($local)));
			$connector->setAttibute($room,$id,'mimeType',$mime);
			
			
		}
});


?>