
ImageObject.setTranslations('de',{
	'ImageObject':'Bild',
	'fillcolor':'Hintergrundfarbe',
	'linecolor':'Rahmenfarbe'
}
);