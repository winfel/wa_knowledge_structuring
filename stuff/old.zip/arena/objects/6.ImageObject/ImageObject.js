/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var ImageObject=Object.create(ContentObject);

ImageObject.isCreatable=true;

ImageObject.register=function(type){
	
	// Registering the object
	
	ContentObject.register.call(this,type);
	
	this.category='Images';
	
	this.content=false;
	
	this.registerAttribute('shadow',{type:'boolean',standard:false,category:'Appearance'});
	
}

ImageObject.register('ImageObject');

ImageObject.execute=function(){
	
	var that=this;
	
	GUI.uploadFile(this,this.translate(GUI.currentLanguage, "please select an image"), "uploadImage");

}

ImageObject.justCreated=ImageObject.execute;

// Override the ContentObject function updateContent as we do not need to get the content in binary here.

ImageObject.updateContent=function(){
	var that=this;
	this.contentAge=this.getAttribute('contentAge');
	that.showContent();
}

ImageObject.isProportional=function(){
	return true;
}

ImageObject.resizeProportional=function(){
	return true;
}

ImageObject.isResizable=function(){
	if (this.hasContent() == false) return false;
	return GraphicalObject.isResizable.call(this);
}