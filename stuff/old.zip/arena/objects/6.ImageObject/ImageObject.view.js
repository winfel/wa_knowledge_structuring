/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/


ImageObject.createRepresentation = function() {
	
	rep = GUI.svg.image(10, 10, 10, 10, this.getContentURL()+'&time='+this.getAttribute('contentAge'));
	
	rep.dataObject=this;

	$(rep).attr("id", this.getAttribute('id'));
	$(rep).attr("contentAge", this.getAttribute('contentAge'));

	this.initGUI(rep);
	
	return rep;
	
}


ImageObject.draw=function(){

	var rep=this.getRepresentation();

	if (this.hasContent() == false) {
		
		//this.setAttribute("height", 101);
		//this.setAttribute("width", 128);
	
		ContentObject.draw.call(this);
		
		$(rep).attr("href", "../images/imageNotFound.png");
		
		this.setViewWidth(128);
		this.setViewHeight(101);
		
	} else {
		
		ContentObject.draw.call(this);
	
		if (this.getAttribute("contentAge") != $(rep).attr("contentAge")) {
			$(rep).attr("href", this.getContentURL()+'&time='+this.getAttribute('contentAge'));
			$(rep).attr("contentAge", this.getAttribute('contentAge'));
		}
	
	}

}
