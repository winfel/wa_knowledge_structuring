
Exit.setTranslations('de',{
	'Room':'Raum'
}
);
