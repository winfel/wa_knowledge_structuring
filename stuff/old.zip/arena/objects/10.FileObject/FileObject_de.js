
FileObject.setTranslations('de',{
	'FileObject':'Datei'
}
);
