/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var FileObject=Object.create(ContentObject);

FileObject.isCreatable=true;


FileObject.register=function(type){
	
	// Registering the object
	
	ContentObject.register.call(this,type);
	
	this.category='Documents';
	
	this.content=false;
	
	this.attributeManager.registerAttribute('layer',{readonly:true});
	this.registerAttribute('width',{readonly:true,getter:function(){return 100},min:100,max:100,standard:100});
	this.registerAttribute('height',{hidden:true,readonly:true,setter:function(){}});
	
	this.unregisterAction('to back');
	this.unregisterAction('to front');
	
}

FileObject.register('FileObject');

FileObject.execute=function(){
	
	var that=this;
	if (!this.hasContent()) {
		this.fireEvent('uploadFile',{explanation:'Bitte eine Datei auswählen:'});
	} else {
		window.location.href=this.getContentURL();
	}

}

FileObject.justCreated=FileObject.execute;

// Override the ContentObject function updateContent as we do not need to get the content in binary here.

FileObject.updateContent=function(){
	var that=this;
	this.contentAge=this.getAttribute('contentAge');
	that.showContent();
}

FileObject.isResizable=function(){
	return false;
}