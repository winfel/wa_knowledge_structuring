/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

FileObject.draw=function(){
	
	GraphicalObject.draw.call(this);
	
	var rep=this.getRepresentation();
	
	
	if (!this.contentAge){
		rep.innerHTML='There is no file data yet. Doubleclick to load a file!';
	} else {

		GUI.setStyle(text, 'height', 'auto');
		GUI.setStyle(text, 'paddingTop', '40px');
		GUI.setStyle(text, 'fontSize', '12px');
		GUI.setStyle(text, 'textAlign', 'center');
		GUI.setStyle(text, 'zIndex', 2000);
		GUI.setStyle(text, 'background', 'transparent url('+this.iconPath+') 50% 0 no-repeat');
		GUI.setStyle(text, 'border', 'none');
		
		rep.innerHTML=this.getAttribute('name');
	}
	
}

FileObject.showContent=function(){
	this.draw();
}