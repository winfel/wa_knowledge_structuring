/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var Paint=Object.create(ImageObject);

Paint.isCreatable=true;

Paint.register=function(type){
	
	// Registering the object
	
	ImageObject.register.call(this,type);
	
	this.category='Paintings';
	
	this.attributeManager.registerAttribute('width',{hidden: true});
	this.attributeManager.registerAttribute('height',{hidden: true});

	this.attributeManager.registerAttribute('fillcolor',{hidden: true});
	this.attributeManager.registerAttribute('linecolor',{hidden: true});
	this.attributeManager.registerAttribute('linesize',{hidden: true});
	this.registerAttribute('shadow',{hidden: true});

	this.registerAction('Edit',function(obj){
		$.each(ObjectManager.getSelected(), function(key, object) {
			object.execute();
		});
	}, true);
	
}


Paint.register('Paint');

Paint.justCreated=function(){

	this.setAttribute("x", 0);
	this.setAttribute("y", 0);

	GUI.editPaint(this);
	
}

Paint.execute=function(){

	GUI.editPaint(this);
	
}



Paint.isResizable=function(){
	return false;
}
