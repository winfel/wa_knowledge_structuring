
Exit.setTranslations('de',{
	'Exit':'Durchgang',
	'destination':'Ziel',
}
);
