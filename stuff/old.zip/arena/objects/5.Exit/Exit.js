/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var Exit=Object.create(IconObject);

Exit.register('Exit');
Exit.isCreatable=true;

Exit.category='Rooms';

Exit.registerAttribute('destination',{type:'text',standard:'',category:'Functionality'});

Exit.execute=function(){
	
	var destination=this.getAttribute('destination');
	
	if (!destination) return;
	
	/* check rights to enter room */
	
	var preloadFunction = function(input) {
		
		var objects=JSON.parse(input);
		
		var roomRights = objects.room.rights;


		if (roomRights.read_content) {

			/* load destination room */
			ObjectManager.loadRoom(destination);

		} else {
			
			/* no rights for destination room --> error */
			GUI.error(GUI.translate("access denied"), GUI.translate("you have no read rights for this room"), false, false);
			
		}
		
	}
	
	Helper.serverCommand({command:'load',
                  room:destination,
                  responseFunction:preloadFunction
                 });
	
	
}