/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var IconObject=Object.create(GraphicalObject);

IconObject.isCreatable=false;

IconObject.setDimensions=function(w,h){
	return;
}

IconObject.register=function(type){
	
	// Registering the object
	
	GraphicalObject.register.call(this,type); //super call
	
	this.category='Objects';
	
	// Registering attributes for graphical objects
	
	var that=this;

	this.attributeManager.registerAttribute('layer',{readonly:true, hidden: true});
	this.registerAttribute('width',{hidden:true});
	this.registerAttribute('height',{hidden:true});
	this.registerAttribute('fillcolor',{hidden:true});
	this.registerAttribute('linecolor',{hidden:true});
	this.registerAttribute('linesize',{hidden:true});
	this.unregisterAction('to back');
	this.unregisterAction('to front');
}

IconObject.register('IconObject');

IconObject.isResizable=function(){
	return false;
}