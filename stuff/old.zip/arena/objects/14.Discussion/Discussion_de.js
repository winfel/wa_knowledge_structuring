Discussion.setTranslations('de',{
	'Discussion':'Diskussion',
        'Title': 'Titel',
        'Change Topic': 'Titel ändern'
});
