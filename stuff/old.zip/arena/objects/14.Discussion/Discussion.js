/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var Discussion=Object.create(ContentObject);

Discussion.isCreatable = true;
Discussion.content = 'New topic';
Discussion.category = 'Discussion';

Discussion.register=function (type) {
	
	// Registering the object
	ContentObject.register.call(this,type);
	this.category='Texts';
	
	this.registerAttribute('font-family',{type:'font',standard:'Arial',category:'Appearance'});
	this.registerAttribute('font-size',{type:'fontsize',min:10,standard:22,unit:'px',category:'Appearance'});
	this.registerAttribute('font-color',{type:'color',standard:'black',category:'Appearance'});
        
        this.registerAttribute('topic',{
            type: 'text',
            standard: undefined,
            category: 'Basic'
        });
        
        this.registerAttribute('Open',{
            type: 'boolean',
            standard: true,
            category: 'Basic'
        });
      	
	this.registerAction('Change Topic',function(){
		$.each(ObjectManager.getSelected(), function(key, object) {
			object.execute(object);
		});
	}, true);
}

Discussion.register('Discussion');

Discussion.execute = function (webarenaObject) {
	
	var style = 'font-family: '+webarenaObject.getAttribute("font-family")+'; ';
	style += 'color: '+webarenaObject.getAttribute("font-color")+'; ';
	style += 'font-size: '+webarenaObject.getAttribute("font-size")+'px;';
	
	GUI.dialog("edit text", '<input type="text" name="textedit" value="'+webarenaObject.getContent()+'" style="'+style+'" />', {
		"save" : function(domContent){
			var value = $(domContent).find("input").attr("value");
			webarenaObject.setContent(value);
                        webarenaObject.setAttribute('topic', value);
		}
	});
    
        GUI.updateInspector(); /// TODO: update object inspector
}

Discussion.isResizable = function () {
	return false;
}