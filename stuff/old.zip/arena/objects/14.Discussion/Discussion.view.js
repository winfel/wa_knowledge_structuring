/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

Discussion.draw = function(){
    var rep = this.getRepresentation();
	
    // align
    this.setViewX(this.getAttribute('x'));
    this.setViewY(this.getAttribute('y'));

    // style
    $(rep).attr("stroke", this.getAttribute('linecolor'));
    $(rep).attr("stroke-width", this.getAttribute('linesize'));
    $(rep).attr("font-size", this.getAttribute('font-size'));
    $(rep).attr("font-family", this.getAttribute('font-family'));
    $(rep).attr("fill", this.getAttribute('font-color'));
}

Discussion.createRepresentation = function() {
    // create physical
    rep = GUI.svg.other('foreignObject');
        
    // create logical
    rep.dataObject = this;
    $(rep).attr("id", this.getAttribute('id'));
    $(rep).attr("width", "200");
    $(rep).attr("height", "200");
        
    // foreign body
    var theBody = document.createElement('body');
    $(theBody).attr('xmlns', 'http://www.w3.org/1999/xhtml');
    $(theBody).attr('style', 'background-color: #0ff');
    
    // content
    $(theBody).append('<h1>'); // Heading
    $(theBody).append('<div>'); // content
    
    // field for typing messagess
    var theInput = document.createElement('input');
    $(theInput).keyup(function (event) {
        if (event.keyCode == 13) { // enter
            var value = $(this).val();
            $(this).parent().find('div').append('<p>' + value + '</p>');
            $(this).val('');
        }
    });
    $(theBody).append(theInput); // message
    
    // push to GUI
    $(rep).append(theBody);
    rep.content = theBody;
    
    // TODO fallback, if foreignObject not accepted by browser
        
    // push to gui
    this.initGUI(rep);
    this.showContent();

    return rep;
}

Discussion.showContent = function () {
    console.log('call Discussion.showContent');
    var rep = this.getRepresentation();
	
    var topic = this.getAttribute('topic');
    if (topic == 0)
    {
        topic = 'New discussion';
    }
    topic = 'Discussion: ' + topic;
        
    $(rep).find('h1').text(topic);
    console.log('Set H1 to:'+topic);
}

Discussion.click = function (e) {
    rep = this.getRepresentation();
    
    // focus input on click
    $(rep).find('input').focus();
};