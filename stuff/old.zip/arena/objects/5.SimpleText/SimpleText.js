/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var SimpleText=Object.create(ContentObject);

SimpleText.isCreatable=true;
SimpleText.content='Neuer Text';

SimpleText.register=function(type){
	
	// Registering the object
	
	ContentObject.register.call(this,type);
	
	this.category='Texts';
	
	this.registerAttribute('font-family',{type:'font',standard:'Arial',category:'Appearance'});
	this.registerAttribute('font-size',{type:'fontsize',min:10,standard:22,unit:'px',category:'Appearance'});
	this.registerAttribute('font-color',{type:'color',standard:'black',category:'Appearance'});
	
	this.attributeManager.registerAttribute('width',{hidden:true});
	this.attributeManager.registerAttribute('height',{hidden:true});
	this.attributeManager.registerAttribute('fillcolor',{hidden:true});
	
	this.registerAction('Edit',function(){
		$.each(ObjectManager.getSelected(), function(key, object) {
			object.execute();
		});
	}, true);
	
}

SimpleText.register('SimpleText');

SimpleText.execute=function(){
	
	this.editText();
	
}

SimpleText.isResizable=function(){
	return false;
}