
SimpleText.setTranslations('de',{
	'SimpleText':'Einfacher Text',
	'font-family':'Schriftart',
	'font-size':'Schriftgröße',
	'font-color':'Schriftfarbe'
}
);
