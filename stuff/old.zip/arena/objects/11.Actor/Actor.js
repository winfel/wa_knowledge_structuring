/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var Actor=Object.create(IconObject);

Actor.register('Actor');
Actor.isCreatable=false;

Actor.category='Lernstatt';

Actor.evaluate=function(){

	//Check, if the actor left or entred a hotspot. Call onLeave or onEnter on
	//the hotspot, if this is the case

	var objects=(ObjectManager.getObjects());	
	
	for (var i in objects){
		var hotspot=objects[i];
		if (hotspot==this) continue;
		if(hotspot.type!=='Hotspot') continue;
		
		hotspot.onLeave();
		if (this.intersectsWith(hotspot)){
			hotspot.onEnter();
		}
		
	}
	
	
}