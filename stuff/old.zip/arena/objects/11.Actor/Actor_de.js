
Actor.setTranslations('de',{
	'Actor':'Akteur'
}
);
