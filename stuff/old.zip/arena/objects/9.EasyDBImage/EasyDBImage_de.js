
EasyDBImage.setTranslations('de',{
	'EasyDBImage':'Bild aus EasyDB'
}
);
