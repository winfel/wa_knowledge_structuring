/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

EasyDBImage.draw=function(){
	
	GraphicalObject.draw.call(this);
	
	var rep=this.getRepresentation();
	
	var reference=this.getAttribute('reference');
	
	if (!reference){
		rep.innerHTML='There is no image data yet. Doubleclick to search in EasyDB!';
	} else {
		rep.innerHTML='';
		
		GUI.setStyle(text, 'background', ('url('+this.getContentURL()+') 50% 50% no-repeat'));
		GUI.setStyle(text, 'backgroundSize', 'auto 100%');
		GUI.setStyle(text, 'backgroundClip', 'padding');
		GUI.setStyle(text, 'backgroundOrigin', 'content');
		
		//background-size: 100%;
    	//background-origin: content

	}
	
}
