/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var EasyDBImage=Object.create(GraphicalObject);

EasyDBImage.isCreatable=true;

EasyDBImage.register=function(type){
	
	// Registering the object
	
	GraphicalObject.register.call(this,type);
	this.registerAttribute('reference',{type:'text',standard:'',readonly:false}); //?? TODO: Must this be visible?
	
	this.category='Images';
	
}

EasyDBImage.register('EasyDBImage');

EasyDBImage.execute=function(){
	
	var that=this;
	this.fireEvent('chooseImage',
	  {explanation: 'Bitte ein Bild suchen und auswählen:',
	   databaseURI: 'server/studiolo/easydb/search.php'
	  });
}

EasyDBImage.justCreated=EasyDBImage.execute;

EasyDBImage.getContentURL=function(){
	return '../server/studiolo/easydb/get.php?id='+this.getAttribute('reference');
}