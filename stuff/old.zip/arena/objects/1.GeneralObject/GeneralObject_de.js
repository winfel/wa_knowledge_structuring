GeneralObject.setTranslations('de',{
	'GraphicalObject':'Grafisches Objekt',
	'name':'Name',
	'type':'Typ',
	'layer':'Ebene',
	'width':'Breite',
	'height':'Höhe',
	'fillcolor':'Füllfarbe',
	'linecolor':'Linienfarbe',
	'Delete':'Löschen',
	'Duplicate':'Duplizieren',
	'to front':'nach vorne',
	'to back':'nach hinten'
}
);