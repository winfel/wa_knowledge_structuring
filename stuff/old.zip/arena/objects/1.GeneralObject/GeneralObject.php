<?php

$connector->registerCommand('save',function() use($connector) {
		$id=$connector->getId();
		if (!$id){$connector->error($connector::ERROR_MISSING_ID,'Missing object id');}
		$room=$connector->getRoom();
		if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
		$data=$connector->getData();
		if (!$data) {$connector->error($connector::ERROR_NO_DATA,'No data');}
		$data['id']=$connector->getID();
		
		$success=$connector->set($room,$id,'object',json_encode($data));
		if ($success) {
			$connector->response('Saved object '.$connector->getID());
		}
		return true;
});


$connector->registerCommand('create',function() use($connector) {
		$data=$connector->getData();
		if (!$data){$connector->error($connector::ERROR_MISSING_DATA,'Missing data');}
		if (!$data['type']){$connector->error($connector::ERROR_MISSING_DATA,'Type specification missing');}
		if (!$data['attributes']){$connector->error($connector::ERROR_MISSING_DATA,'Attribute set missing');}
		if (!$data['layer']){$connector->error($connector::ERROR_MISSING_DATA,'Layer is missing');}
	
		$attributes=$data['attributes'];
		$type=$data['type'];
		$layer=$data['layer'];
		
	 	$room=$connector->getRoom();
	 	if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
	 	
		$id=$connector->create($room,$type);
		if (!$id){$connector->error($connector::ERROR_NO_WRITE_RIGHT,'Could not write the object');}
		
		$attributes['type']=$type;
		$attributes['id']=$id;
		$attributes['layer']=$layer;
		
		$success=$connector->set($room,$id,'object',json_encode($attributes));
		if ($success) {
			$connector->response('Created object '.$id);
		}
		return true;
});


$connector->registerCommand('delete',function() use($connector) {
		$objects=$connector->getData();
		$room=$connector->getRoom();
		
		if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
		if (!$objects){$connector->error($connector::ERROR_MISSING_DATA,'Missing object ids for deletion');}
		
		foreach ($objects as $id){
			$connector->delete($room,$id);
		}
		
		$connector->response('Finished');
	
});


$connector->registerCommand('duplicate',function() use($connector) {$connector::error(0,'Not implemented yet');});


$connector->registerCommand('load',function() use($connector) {
		$room=$connector->getRoom();
		
		if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
		
		$objects=$connector->load($room);
		
		$connector->response($objects);
});



$connector->registerCommand('getHomeroom',function() use($connector) {
		return $connector->getHomeroom();
});


?>