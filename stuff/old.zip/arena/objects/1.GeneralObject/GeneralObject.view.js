/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

GraphicalObject.draw=function(){
	
	var rep=this.getRepresentation();

	this.setViewWidth(this.getAttribute('width'));
	this.setViewHeight(this.getAttribute('height'));
	this.setViewX(this.getAttribute('x'));
	this.setViewY(this.getAttribute('y'));
			
	$(rep).attr("layer", this.getAttribute('layer'));
	
	if (!$(rep).hasClass("webarena_ghost")) {
		if (this.getAttribute("visible") || this.selected) {
			$(rep).css("visibility", "visible");
		} else {
			$(rep).css("visibility", "hidden");
		}
	}
		
	this.adjustControls();
	
}

GraphicalObject.updateGUI=function(){
	
	//check if we are allowed to paint
	
	if (!ObjectManager) return;
	if (!ObjectManager.hasObject(this)){
		debug(this+' not in inventory');
		return;
	}
	
	this.draw();
	
	GUI.updateGUI(this);
	
}

/**
 * getRepresentation - get access to the dom representation of the object on
 *					   the surface.
 *
 * Always use this function to gain access to the representation. This should 
 * always be done in view-subsections of the objects and must never be done 
 * elsewhere.
 */
GraphicalObject.getRepresentation=function(){

	var rep=document.getElementById(this.getAttribute('id'));

	if (!rep){
		
		return this.createRepresentation();
		
	}
	return rep;
}



GraphicalObject.createRepresentation = function() {

	rep = GUI.svg.rect(
		10, //x
		10, //y
		10, //width
		10 //height
	);

	rep.dataObject=this;

	$(rep).attr("id", this.getAttribute('id'));

	this.initGUI(rep);
	
	return rep;
	
}


GraphicalObject.initGUI = function(rep) {
	
	var self = this;
	
	$(rep).click(function(event) {

		if (!self.selected) {
			self.click(event);
		}
		
	});
	
}


GraphicalObject.addSelectedIndicator = function() {
	$(this.getRepresentation()).attr("filter", "url(#svg-selected)");
}

GraphicalObject.removeSelectedIndicator = function() {
	$(this.getRepresentation()).attr("filter", "");
}


GraphicalObject.select = function(multiple) {

	if (this.selected) return;

	if (GUI.hiddenObjectsVisible && !this.getAttribute("hidden")) return;
	if (!GUI.hiddenObjectsVisible && this.getAttribute("hidden")) return;
	
	if (!GUI.shiftKeyDown && !multiple) {
	
		/* deselect all selected objects */
		$.each(ObjectManager.getSelected(), function(index, object) {
			object.deselect();
		});
	
	}
	
	this.selected = true;
	
	if (this.mayResize()) {
		this.addControls();
	}
	
	if (this.mayMove()) {
		this.makeMovable();
	}
	
	this.addSelectedIndicator();
	
	this.selectHandler();
	
	this.draw();
	
	GUI.refreshSVG();

}

GraphicalObject.deselect = function() {

	if (!this.selected) return;

	this.selected = false;
	
	this.removeControls();
	this.unmakeMovable();

	this.removeSelectedIndicator();
	
	this.deselectHandler();
	
	this.draw();
	
}


GraphicalObject.adjustControls = function() {
	
	var self = this;
	
	var rep = this.getRepresentation();
	
	if (this.controls) {
	$.each(this.controls, function(index, control) {
		
		if (control.type == "x") {
			var x = self.getViewBoundingBoxX()+self.getViewBoundingBoxWidth();
			var y = self.getViewBoundingBoxY()+self.getViewBoundingBoxHeight()/2;
		}

		if (control.type == "y") {
			var x = self.getViewBoundingBoxX()+self.getViewBoundingBoxWidth()/2;
			var y = self.getViewBoundingBoxY()+self.getViewBoundingBoxHeight();
		}
		
		if (control.type == "xy") {
			var x = self.getViewBoundingBoxX()+self.getViewBoundingBoxWidth();
			var y = self.getViewBoundingBoxY()+self.getViewBoundingBoxHeight();
		}

		$(control).attr("cx", x);
		$(control).attr("cy", y);
		
	});
	}
	
}

GraphicalObject.addControls = function() {
		
	var self = this;
	
	this.controls = {};

	this.addControl("x", function(dx, dy, startWidth, startHeight, rep) {
		
		if (self.resizeProportional()) {
			
			var width = startWidth+dx;
			var height = startHeight*(width/startWidth);
			
			if (width >= 10) {
				self.setViewWidth(width);
			}

			if (height >= 10) {
				self.setViewHeight(height);
			}
			
		} else {
			
			var width = startWidth+dx;
			
			if (width < 10) return;
			self.setViewWidth(width);
			
		}
		
	});

	this.addControl("y", function(dx, dy, startWidth, startHeight, rep) {
		
		if (self.resizeProportional()) {
			
			var height = startHeight+dy;
			var width = startWidth*(height/startHeight);
			
			if (width >= 10) {
				self.setViewWidth(width);
			}

			if (height >= 10) {
				self.setViewHeight(height);
			}
			
		} else {
			
			var height = startHeight+dy;
			
			if (height < 10) return;
			self.setViewHeight(height);
			
		}
		
	});

	this.addControl("xy", function(dx, dy, startWidth, startHeight, rep) {
		
		if (self.resizeProportional()) {
			/* resize proportional */
			
			if (dx > dy) {
				
				var width = startWidth+dx;
				var height = startHeight*(width/startWidth);
				
			} else {
				
				var height = startHeight+dy;
				var width = startWidth*(height/startHeight);
				
			}
			
			if (width >= 10 && height >= 10) {
				self.setViewWidth(width);
				self.setViewHeight(height);
			}

		} else {
			
			var width = startWidth+dx;
			var height = startHeight+dy;
			
			if (width >= 10) {
				self.setViewWidth(width);
			}

			if (height >= 10) {
				self.setViewHeight(height);
			}
			
		}
		
		
	
	});
	
}

GraphicalObject.removeControls = function() {
	
	$("#content").find(".webarenaControl_"+this.data.id).each(function() {
		GUI.svg.remove(this);
	});

	this.controls = {};
	
}

GraphicalObject.addControl = function(type, resizeFunction) {

	var self = this;

	var rep = this.getRepresentation();

	var control = GUI.svg.circle(
		10, //cx
		10, //cy
		7, //radius
		{
			fill: "#008DDF",
			stroke: "#FFFFFF",
			strokeWidth: 2,
			filter: "url(#svg-drop-shadow)"
		}
	);
	
	$(control).addClass("webarenaControl_"+this.data.id);
	$(control).attr("layer", 10000000);

	control.moving = false;
	
	control.type = type;
	

	var start = function(event) {
		
		event.preventDefault();
		
		GUI.hideActionsheet();
		GUI.hideLinks(self);

		control.startMouseX = event.pageX;
		control.startMouseY = event.pageY;
		control.objectStartWidth = self.getViewWidth();
		control.objectStartHeight = self.getViewHeight();
		
		control.moving = true;
		
		var move = function(event) {

			if (!control.moving) return;
			
			event.preventDefault();

			var dx = event.pageX-control.startMouseX;
			var dy = event.pageY-control.startMouseY;

			/* resize object */
			resizeFunction(dx, dy, control.objectStartWidth, control.objectStartHeight, rep);
			
			self.adjustControls();
			
			self.resizeHandler();
					
		};
		
		var end = function(event) {
			
			event.preventDefault();
			
			control.moving = false;
			
			GUI.showLinks(self);
			
			$("#content").unbind("mousemove.webarenaMove");
			$("#content").unbind("mouseup.webarenaMove");
			
			$("#content").unbind("touchmove.webarenaMove");
			$("#content").unbind("touchend.webarenaMove");
			
		};
		
		$("#content").bind("mousemove.webarenaMove", move);
		$(control).bind("touchmove.webarenaMove", move);
		
		$("#content").bind("mouseup.webarenaMove", end);
		$(control).bind("touchend.webarenaMove", end);
			
	};
	
	$(control).bind("mousedown", start);
	$(control).bind("touchstart", start);
	

	
	this.controls[type] = control;
	
	this.adjustControls();
	
}


GraphicalObject.saveMoveStartPosition = function() {
	
	this.moveObjectStartX = this.getViewX();
	this.moveObjectStartY = this.getViewY();
	
}


GraphicalObject.makeMovable = function() {
	
	var self = this;
	
	var rep = this.getRepresentation();
	
	var start = function(event) {
		
		event.preventDefault();
		
		GUI.hideActionsheet();
		GUI.hideLinks(self);

		self.moveStartMouseX = event.pageX;
		self.moveStartMouseY = event.pageY;
		
		/* save start position for all selected objects */
		$.each(ObjectManager.getSelected(), function(index, object) {
			object.saveMoveStartPosition();
		});
		
		self.moving = true;
		self.moved = false;
		
		var move = function(event) {

			if (!self.moving) return;
			
			event.preventDefault();
			
			self.moved = true;

			var dx = event.pageX-self.moveStartMouseX;
			var dy = event.pageY-self.moveStartMouseY;

			/* move all selected objects */
			$.each(ObjectManager.getSelected(), function(index, object) {
				object.moveRelative(dx, dy);
			});

		};
		
		var end = function(event) {
			
			event.preventDefault();
			
			self.moving = false;
			
			GUI.showLinks(self);
			
			if (!self.moved) {
				self.click(); ///// XXXXXXXX
			}
			
			$("#content").unbind("mousemove.webarenaMove");
			$("#content").unbind("mouseup.webarenaMove");
			
		};
		
		$("#content").bind("mousemove.webarenaMove", move);
		$("#content").bind("touchmove.webarenaMove", move);
		
		$("#content").bind("mouseup.webarenaMove", end);
		$("#content").bind("touchend.webarenaMove", end);
			
	};
	
	$(rep).bind("mousedown", start);
	$(rep).bind("touchstart", start);
	
}


GraphicalObject.moveRelative = function(dx, dy) {

	this.setViewX(this.moveObjectStartX+dx);
	this.setViewY(this.moveObjectStartY+dy);
	
	this.adjustControls();
	
	this.moveHandler();
	
}


GraphicalObject.moveBy = function(x, y) {

	this.setViewX(this.getViewX()+x);
	this.setViewY(this.getViewY()+y);
	
	this.adjustControls();
	
	this.moveHandler();
	
	GUI.hideLinks(this);
	GUI.showLinks(this);
	
}


GraphicalObject.unmakeMovable = function() {
	
	var rep = this.getRepresentation();
	
	$(rep).unbind("mousedown");
	$(rep).unbind("touchstart");
	
}


/* view getter */

/* get the x position of the object (this must not be the left position of the object) */
GraphicalObject.getViewX = function() {
	var rep = this.getRepresentation();
	return parseInt($(rep).attr("x"));
}

/* get the y position of the object (this must not be the top position of the object) */
GraphicalObject.getViewY = function() {
	var rep = this.getRepresentation();
	return parseInt($(rep).attr("y"));
}

/* get the width of the object */
GraphicalObject.getViewWidth = function() {
	var rep = this.getRepresentation();
	return parseInt($(rep).attr("width"));
}

/* get the height of the object */
GraphicalObject.getViewHeight = function() {
	var rep = this.getRepresentation();
	return parseInt($(rep).attr("height"));
}

/* get the x position of the objects bounding box (this is the left position of the object) */
GraphicalObject.getViewBoundingBoxX = function() {

	var rep = this.getRepresentation();
	
	if ($(rep).attr("moveByTransform")) {
		return this.getViewX();
	} else {
		return this.getRepresentation().getBBox().x;
	}

}

/* get the y position of the objects bounding box (this is the top position of the object) */
GraphicalObject.getViewBoundingBoxY = function() {
	
	var rep = this.getRepresentation();
	
	if ($(rep).attr("moveByTransform")) {
		return this.getViewY();
	} else {
		return this.getRepresentation().getBBox().y;
	}
	
}

/* get the width of the objects bounding box */
GraphicalObject.getViewBoundingBoxWidth = function() {
	
	return parseInt(this.getRepresentation().getBBox().width);
	
}

/* get the height of the objects bounding box */
GraphicalObject.getViewBoundingBoxHeight = function() {
	
	return parseInt(this.getRepresentation().getBBox().height);
	
}




/* view setter */

GraphicalObject.setViewX = function(value) {

	var self = this;
	
	var rep = this.getRepresentation();
	
	if ($(rep).attr("moveByTransform")) {
		$(rep).attr("transform", "translate("+value+","+self.getViewY()+")");	
	}
	
	$(rep).attr("x", value);
	
	GUI.adjustContent(this);
	
}

GraphicalObject.setViewY = function(value) {

	var self = this;

	var rep = this.getRepresentation();
	
	if ($(rep).attr("moveByTransform")) {
		$(rep).attr("transform", "translate("+self.getViewX()+","+value+")");
	}
	
	$(rep).attr("y", value);
	
	GUI.adjustContent(this);

}

GraphicalObject.setViewWidth = function(value) {
	$(this.getRepresentation()).attr("width", value);
	GUI.adjustContent(this);
}

GraphicalObject.setViewHeight = function(value) {
	$(this.getRepresentation()).attr("height", value);
	GUI.adjustContent(this);
}



/* our own click handler (because we have to differ single click and double click) */
GraphicalObject.click = function(event) {

	var self = this;
        
	if (self.clickTimeout) {
		/* second click */
		window.clearTimeout(self.clickTimeout);
		self.clickTimeout = false;

		if (GUI.shiftKeyDown) return;

		//perform dblclick action
		self.clickRevertHandler();
		self.dblclickHandler();
                
	} else {
		/* first click */
		self.clickTimeout = window.setTimeout(function() {
			self.clickTimeout = false;
		}, 300);
                
                /// @TODO router to enable navigation / history in browser
                /// @TODO bug: on selecting multiple (shift-modifier)
                // set routing hash for selected item
                window.location.hash = '#' + ObjectManager.getCurrentRoomId()
                                     + '/' + self.data.id;
		self.clickHandler();
	}

}



/* handler functions */

GraphicalObject.clickHandler = function() {
	if (this.selected) {
		this.selectedClickHandler();
	} else {
		this.select();
	}
}

GraphicalObject.clickRevertHandler = function() {
	/* for a faster feeling the click event is called when the first click is recognized, even if there will be a second (double) click. In case of a double click we have to revert the click action */
	this.deselect();
}

GraphicalObject.moveHandler = function() {
	this.setPosition(this.getViewX(), this.getViewY());	
}

GraphicalObject.resizeHandler = function() {
	this.setDimensions(this.getViewWidth(), this.getViewHeight());
}

GraphicalObject.selectHandler = function() {
	GUI.updateInspector();
	GUI.showLinks(this);
}

GraphicalObject.deselectHandler = function() {
	GUI.hideLinks(this);
}

GraphicalObject.dblclickHandler = function() {
	this.execute();
}

GraphicalObject.selectedClickHandler = function() {

	if (GUI.shiftKeyDown) {
		this.deselect();
	} else {
		
		var x = this.getViewBoundingBoxX()+this.getViewBoundingBoxWidth()/2;
		var y = this.getViewBoundingBoxY();

		GUI.showActionsheet(x, y, this);
	
	}
	
}

GraphicalObject.setDisplayGhost = function(s) {
	this.displayGhost = s;
	this.draw();
}



