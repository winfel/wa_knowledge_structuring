/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var GeneralObject=Object.create(Object);

var GraphicalObject=GeneralObject; //conveiniance

GeneralObject.data=false;	  //the data member contains all data that is saved later
GeneralObject.attributes=GeneralObject.data;
GeneralObject.attributeManager=false;
GeneralObject.translationManager=false;
GeneralObject.actionManager=false;
GeneralObject.isCreatable=false;
GeneralObject.isGraphical=true;
GeneralObject.name='Graphical Object';
GeneralObject.selected=false;
GeneralObject.category = 'Graphical Elements';

/**
*	Register this object type in the object manager
*
*	Call this on object types that inherit from GraphicalObject.
*
*   For example:
*
*		var Square=Object.create(GraphicalObject);
*       Square.register('Square');
*
*		Square.otherfunction=function() {...}
*
*   @param type the object type (String)
*/
GeneralObject.register=function(type){
	
	var that=this;
	
	this.type=type;
	this.standardData=new DataSet;
	ObjectManager.registerType(type,this);
	this.attributeManager=Object.create(AttributeManager);
	this.translationManager=Object.create(TranslationManager);
	this.actionManager=Object.create(ActionManager);
	this.attributeManager.init(this);
	this.translationManager.init(this);
	this.actionManager.init(this);
	this.registerAttribute('id',{type:'number',readonly:true});
	this.registerAttribute('type',{type:'text',readonly:true});
	this.registerAttribute('name',{type:'text'});
    
    this.attributeManager.registerAttribute('layer',{type:'layer',readonly:false,category:'Dimensions'});
	this.attributeManager.registerAttribute('x',{type:'number',min:0,category:'Dimensions'});
	this.attributeManager.registerAttribute('y',{type:'number',min:0,category:'Dimensions'});
	this.attributeManager.registerAttribute('width',{type:'number',min:5,standard:100,unit:'px',category:'Dimensions'});
	this.attributeManager.registerAttribute('height',{type:'number',min:5,standard:100,unit:'px',category:'Dimensions'});
	this.attributeManager.registerAttribute('fillcolor',{type:'color',standard:'transparent',category:'Appearance'});
	this.attributeManager.registerAttribute('linecolor',{type:'color',standard:'black',category:'Appearance'});
	this.attributeManager.registerAttribute('linesize',{type:'number',min:1,standard:1,category:'Appearance'});
	this.attributeManager.registerAttribute('hidden',{type:'boolean',standard:false,category:'Basic',checkFunction: function(object, value) {
		GUI.toggleHidden();
	}});
	this.attributeManager.registerAttribute('locked',{type:'boolean',standard:false,category:'Basic',checkFunction: function(object, value) {
		
		window.setTimeout(function() {
			object.deselect();
			object.select();
		}, 10);

		return true;
		
	}});
	
	this.attributeManager.registerAttribute('visible',{type:'boolean',standard:true,category:'Basic',checkFunction: function(object, value) {
		
		if (!object.hasLinkedObjects() && value == false) {
			return "you need at least one link from or to this object to hide it";
		} else {
			return true;
		}
		
	}});
	
	this.attributeManager.registerAttribute('link',{type:'object_id',multiple: true, standard:[],category:'Functionality',changedFunction: function(object, value) {
		
		$.each(ObjectManager.getObjects(), function(index, object) {

			if (!object.hasLinkedObjects() && object.getAttribute("visible") != true) {
				object.setAttribute("visible", true);
			}
			
		});
		
		return true;
		
	}});
	
	this.registerAction('Delete',function(){
		
		$.each(ObjectManager.getSelected(), function(key, object) {
			object.deleteIt();
		});
		
	},false);
	
	this.registerAction('Duplicate',function(){
		
		$.each(ObjectManager.getSelected(), function(key, object) {
			object.duplicate();
		});
		
	},false);
	
	var r=Helper.getRandom(0,200);
	var g=Helper.getRandom(0,200);
	var b=Helper.getRandom(0,200);
	var width=100;		

	this.standardData.fillcolor='rgb('+r+','+g+','+b+')';
	this.standardData.width=width;
	this.standardData.height=width;
	
	this.registerAction('to front',function(){
		
		var selection=ObjectManager.getSelection();
		if (!selection) return;
		
		for (var i=0;i<selection.length;i++){
			var obj=selection[i];
			
			var oldObjects=ObjectManager.objects;
			var newObjects=new Array();

			for (var j=0;j<oldObjects.length;j++){
				var o=oldObjects[j];
				if (o!==obj) newObjects.push(o);
			}
			newObjects.push(obj);
			ObjectManager.objects=newObjects;
			ObjectManager.updateLayers();
			
		}
		
	}, false);
	
	this.registerAction('to back',function(){
		
		var selection=ObjectManager.getSelection();
		if (!selection) return;
		
		for (var i=selection.length-1;i>=0;i--){

			var obj=selection[i];

			var oldObjects=ObjectManager.objects;
			var newObjects=new Array();

			newObjects.push(obj);

			for (var j=0;j<oldObjects.length;j++){
				var o=oldObjects[j];
				if (o!==obj) newObjects.push(o);
			}
			
			ObjectManager.objects=newObjects;
			ObjectManager.updateLayers();

		}
		
	}, false);

	
	
}



/**
*	initialize the graphical object by providing an id. Registers the object
*	within the object manager and draws it.
*
*	Call this on actual objects! (should be done by the object manager)
*
*	@param id the id of the actual object
*/	
GeneralObject.init=function(id){
	if (!this.data) this.data=new DataSet;
	
	if(this.data.id) return;
	
	//debug('Init for '+id+' '+this.type);
	
	this.data.id=id;
	this.data.type=this.type;
	this.data.layer=ObjectManager.getNextLayer();
	ObjectManager.add(this);
	this.draw();
}

GeneralObject.getCategory=function(){
	return this.category;
}

GeneralObject.registerAttribute=function(attribute,setter,type,min,max){
	return this.attributeManager.registerAttribute(attribute, setter,type, min, max);
}

GeneralObject.setAttribute=function(attribute,value){
	
	if (this.mayChangeAttributes()){
		
		//rights could also be checked in the attribute manager but HAVE to
		//be checked on the server side.
		
		return this.attributeManager.setAttribute(this,attribute,value);
	} else {
		GUI.error('Missing rights','No right to change '+attribute+' on '+this,this);
		return false;
	}
}

GeneralObject.getAttribute=function(attribute){
	return this.attributeManager.getAttribute(this,attribute);
}

GeneralObject.hasAttribute=function(attribute){
	return this.attributeManager.hasAttribute(this,attribute);
}

GeneralObject.getAttributes=function(){
	var attInfo=this.attributeManager.getAttributes();
	attInfo = jQuery.extend(true, {}, attInfo); //deep copy object
	for (var i in attInfo){
		var info=attInfo[i];
		info.value=this.getAttribute(i);
		attInfo[i]=info;
	}
	return attInfo;
}

GeneralObject.registerAction=function(name, func, single){
	return this.actionManager.registerAction(name,func, single);
}

GeneralObject.unregisterAction=function(name){
	return this.actionManager.unregisterAction(name);
}

GeneralObject.performAction=function(name){
	return this.actionManager.performAction(name,this);
}

GeneralObject.getActions=function(){
	return this.actionManager.getActions();
}

GeneralObject.translate=function(language, text){
	if (!this.translationManager) return text;
	return this.translationManager.get(language, text);
}

GeneralObject.setTranslations=function(language,data){
	return this.translationManager.addTranslations(language, data);
}

GeneralObject.setTranslation=GeneralObject.setTranslations;

/**
*	get the current object data in readable form.
*/
GeneralObject.toString=function(){
	    if (!this.data) {
	    	return 'type '+this.type;
	    }
		return this.type+' #'+this.data.id;//+' '+this.data;
}	

GeneralObject.getType=function(){
	return this.getAttribute('type');
}

GeneralObject.getName=function(){
	return this.getAttribute('name');
}

GeneralObject.getId=function(){
	return this.getAttribute('id');
}

GeneralObject.justCreated=function(){
	//debug('Just created '+this);
}

/** 
 *	save the current object data to the datamanger, called internally by persist
 *
 */ 
   GeneralObject.saveDelayed=function(){

	// the actual save operation is delayed for 100ms.
	// If severaly save operations are called on the same object
	// within this time, the timeout is cancelled
	
	GUI.objectSaved(this);
	
	if (this.saveTimeout) {
		window.clearTimeout(this.saveTimeout);
		this.saveTimeout=false;
	}
	
	ObjectManager.resetReloadCountdown();
	
	this.saveTimeout=window.setTimeout(this.save,100,this);
}

GeneralObject.save=function(that){
	
	GUI.objectSaved(this);
	
	ObjectManager.resetReloadCountdown();
	
	Helper.serverCommand({command:'save',
	                      room:that.getCurrentRoom(),
	                      id:that.data.id,
	                      data:that.data,
	                      responseFunction:function(response){ObjectManager.resetReloadCountdown();}
	                     });
}

/**
*	Remove the object from data structures and from the screen. Do not call
*   this to remove an object from a room as it will automatically reappear
*   on the next reaload. Use delete instead;
*/
GraphicalObject.remove=function(){
	
	// Remove the visual representation
	var rep=this.getRepresentation();
	
	this.deselect();
	$(rep).remove();
	
	// Remove the object from the ObjectManager
	ObjectManager.remove(this);
	
	// Empty object
	for (var i in this){
		delete(this[i]);
	}
}

GeneralObject.deleteIt=function(){
	debug('Calling deleteIt on '+this);
	var ids=[];
	ids.push(this.getAttribute('id'));
	
	this.persistNow();
	
	Helper.serverCommand({command:'delete',
                      room:this.getCurrentRoom(),
                      data:ids,
                      responseFunction:ObjectManager.load
                     });
}

	
/**
*	start the evaluation of this object, called internally by persist
*/
GeneralObject.evaluateDelayed=function(){
	// Prevent a loop of evaluations. When an evaluation is taking place,
	// further operations on the same object are not evaluated any morge
	if (this.evaluating) return;
	if (this.evaluateTimeout) {
		window.clearTimeout(this.evaluateTimeout);
		this.evaluateTimeout=false;
	}
	
	this.evaluateTimeout=window.setTimeout(this.evaluateInt,100,this);
}

GeneralObject.evaluateNow=function(){
	// Prevent a loop of evaluations. When an evaluation is taking place,
	// further operations on the same object are not evaluated any morge
	if (this.evaluating) return;
	if (this.evaluateTimeout) {
		window.clearTimeout(this.evaluateTimeout);
		this.evaluateTimeout=false;
		this.evaluateInt(this);
	}
}

GeneralObject.saveNow=function(){
	
	if (this.saveTimeout) {
		//debug ('saveNow on '+this);
		window.clearTimeout(this.saveTimeout);
		this.saveTimeout=false;
		this.save(this);
	}
}

GeneralObject.evaluateInt=function(that){
	if (that.mayEvaluate()) {
		that.evaluating=true;
		that.evaluate();
		that.evaluating=false;
	} else {
		debug('Not evaluating '+that);
	}
}

GeneralObject.execute=function(){
}

/**
*	the actual evaluaction code has to be put in here by actual object types
*/
GeneralObject.evaluate=function(){
	//Override here
}

/**
 * 	persist the current object
 *
 */
GeneralObject.persist=function(){
	this.evaluateDelayed();
	this.saveDelayed();
}

GeneralObject.persistNow=function(){
	this.evaluateNow();
	this.saveNow();
}

GeneralObject.getCurrentRoom=function(){
	return ObjectManager.currentRoom.data.id;
}

GeneralObject.stopOperation=function(){
}

/*
* rights
*/


GeneralObject.mayReadContent=function() {
	return this.data.rights.read_content;
}

GeneralObject.mayChangeAttributes=function(){
	return this.data.rights.change_attributes;
}

GeneralObject.mayChangeContent=function(){
	return this.data.rights.change_content;
}

GeneralObject.mayEvaluate=function(){
	return this.data.rights.evaluate;
}



GeneralObject.hasLinkedObjects=function() {
	
	var counter = 0;
	
	$.each(this.getLinkedObjects(), function(id, object) {
		counter++;
	});
	
	if (counter > 0) {
		return true;
	} else {
		return false;
	}
}

GeneralObject.getLinkedObjects=function() {
	var self = this;
	
	/* get objects linked by this object */
	var ownLinkedObjectsIds = [];

	if (this.data.link instanceof Array) {
		ownLinkedObjectsIds.concat(this.data.link);
	} else {
		ownLinkedObjectsIds.push(this.data.link);
	}
	
	/* get objects which link to this object */
	var linkingObjectsIds = [];
	
	$.each(ObjectManager.getObjects(), function(index, object) {

		if (object.data.link) {
			
			if (object.data.link instanceof Array) {
				
				$.each(object.data.link, function(index, objectId) {
				
					if (objectId == self.data.id) {
						linkingObjectsIds.push(object.data.id);
					}
					
				});
				
			} else {

				if (object.data.link == self.data.id) {
					linkingObjectsIds.push(object.data.id);
				}
				
			}
			
		}
		
	});

	
	var links = {};

	if (ownLinkedObjectsIds) {

		$.each(ownLinkedObjectsIds, function(index, objectId) {
			if (!objectId) return;

			var webarenaObject = ObjectManager.getObject(objectId);

			links[objectId] = {
				object : webarenaObject,
				direction : "out"
			}

		});
	}
	
	
	if (linkingObjectsIds) {

		$.each(linkingObjectsIds, function(index, objectId) {
			if (!objectId) return;

			var webarenaObject = ObjectManager.getObject(objectId);

			links[objectId] = {
				object : webarenaObject,
				direction : "in"
			}

		});
	}

	return links;
	
}




GraphicalObject.hide=function(){
	this.setAttribute('hidden',true);
}

GraphicalObject.unHide=function(){
	this.setAttribute('hidden',false);
}

/**
*	move the object by dx,dy pixels
*/
GraphicalObject.move=function(dx,dy){
	this.setAttribute('x',this.getAttribute('x')+dx);
	this.setAttribute('y',this.getAttribute('y')+dy);
}		
	
/**
*	put the top left edge of the bounding box to x,y
*/
GraphicalObject.setPosition=function(x,y){
	this.setAttribute('x',x);
	this.setAttribute('y',y);
}
		
/**
*	update the object's width and height
*/
GraphicalObject.setDimensions=function(width,height){
	if (!height) height=width;
	this.setAttribute('width',width);
	this.setAttribute('height',height);
}

	
/**
*	determine if a given point is within the current object
*/
GraphicalObject.boxContainsPoint=function(px,py){
	return this.boxIntersectsWith(px,py,0,0);
}
	
/**
*	determine if the current object intersects with the square x1,y1,x2,y2
*/
GraphicalObject.boxIntersectsWith=function(otherx,othery,otherwidth,otherheight){
	
	var thisx=this.getViewBoundingBoxX();
	var thisy=this.getViewBoundingBoxY();
	var thisw=this.getViewBoundingBoxWidth();
	var thish=this.getViewBoundingBoxHeight();
	
	if (otherx+otherwidth<thisx) {
		return false;
	}
	if (otherx>thisx+thisw) {
		return false;
	}
	if (othery+otherheight<thisy) {
		return false;
	}
	if (othery>thisy+thish) {
		return false;
	}
	
	return true;
}

GraphicalObject.intersectsWith=function(other){
	
	//Check if other object is graphical
	
	if (!other.isGraphical) return false;
	
	//Check if the boxes overlap.
	
	var x=other.getAttribute('x');
	var y=other.getAttribute('y');
	var w=other.getRepresentation().offsetWidth;
	var h=other.getRepresentation().offsetHeight;
	
	//if objects are hidden, sizes cannot be determined by offsetWidth and offsetHeight
	
	if (!w) w=other.getAttribute('width');
	if (!h) h=other.getAttribute('height');
	
	if (!this.boxIntersectsWith(x,y,w,h)) return false;
	
	//Check pixelwise
	
	//This could be optimized by only checking in the overlapping region
	
	for (var xi=x+5;xi<x+w;xi+=10){
		for (var yi=y+5;yi<y+h;yi+=10){
			if (this.hasPixelAt(xi,yi) && other.hasPixelAt(xi,yi)) return true;
		}
	}
	
	return false;
	
}

GraphicalObject.contains=function(other){
	
	//Check if other object is graphical
	
	if (!other.isGraphical) return false;
	
	//Check if the boxes overlap.
	
	var x=other.getAttribute('x');
	var y=other.getAttribute('y');
	var w=other.getAttribute('width');
	var h=other.getAttribute('height');
	
    //if objects are hidden, sizes cannot be determined by offsetWidth and offsetHeight
	
	if (!w) w=other.getAttribute('width');
	if (!h) h=other.getAttribute('height');
	
	if (!this.boxIntersectsWith(x,y,w,h)) return false;

	//Check pixelwise
	
	for (var xi=x;xi<x+w;xi+=10){
		for (var yi=y;yi<y+h;yi+=10){
			if (other.hasPixelAt(xi,yi) && !this.hasPixelAt(xi,yi)) {
				return false;
			}
		}
	}
	
	return true;
	
}

GraphicalObject.hasPixelAt=function(x,y){
	
	//assume, that the GraphicalObject is full of pixels.
	//override this if you can determine better, where there
	//object is nontransparent
	
	return this.boxIntersectsWith(x,y);
}



GraphicalObject.evaluate=function(){
	
}

GraphicalObject.toFront=function(){
	ObjectManager.performAction("toFront");
}

GraphicalObject.toBack=function(){
	ObjectManager.performAction("toBack");
}

GraphicalObject.setLayer=function (layer){
	if (layer==this.data.layer) return;
	this.data.layer=layer;
	this.persist();
}
	
	
/**
 * 	persist the current object
 *
 * 	draw the current object and save the object data to the datamanager
 */
GraphicalObject.persist=function(){
	this.updateGUI();
	this.evaluateDelayed();
	this.saveDelayed();
}   


GraphicalObject.isMovable=function(){
	return this.mayChangeAttributes();
}

GraphicalObject.isResizable=function(){
	return this.isMovable();
}

GraphicalObject.resizeProportional=function(){
	return false;
}


/* following functions are used by the GUI. (because the three functions above will be overwritten) */
GraphicalObject.mayMove=function() {
	if (this.getAttribute('locked')) {
		return false;
	} else {
		return this.isMovable();
	}
}

GraphicalObject.mayResize=function() {
	if (this.getAttribute('locked')) {
		return false;
	} else {
		return this.isResizable();
	}
}

GraphicalObject.mayResizeProportional=function() {
	if (this.getAttribute('locked')) {
		return false;
	} else {
		return this.resizeProportional();
	}
}


GraphicalObject.execute=function(){
	this.toFront();
}

GraphicalObject.isSelected = function() {
	return this.selected;
}




GeneralObject.register('GeneralObject');