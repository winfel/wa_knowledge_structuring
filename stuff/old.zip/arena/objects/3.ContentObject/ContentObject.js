/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var ContentObject=Object.create(GraphicalObject);

ContentObject.isCreatable=false;
ContentObject.contentAge=0;
ContentObject.content=null;

ContentObject.name='Content Object';

ContentObject.register=function(type){
	
	// Registering the object
	
	GraphicalObject.register.call(this,type); //super call
	
	this.registerAttribute('contentAge',{type:'timestamp',readonly:true,hidden:true}); //Should be hidden, visible for debug reasons
	this.registerAttribute('mimeType',{type:'string',readonly:true,hidden:false,standard:'text/plain'});
	
	this.standardData.fillcolor='transparent';
	this.standardData.linecolor='transparent';
	this.standardData.width=300;
	this.standardData.height=200;
	
}

ContentObject.register('ContentObject');

ContentObject.getContentURL=function(){
	return '../../server/connector.php?command=getRawContent&room='+this.getCurrentRoom()+'&id='+this.getAttribute('id');
}

ContentObject.updateContent=function(){
	
	if (this.mayReadContent()) {
	
		var that=this;
		this.contentAge=this.getAttribute('contentAge');
		Helper.serverCommand({command:'getContent',
		       room:this.getCurrentRoom(),
		       id:this.getAttribute('id'),
		       responseFunction:function(content){
		       	    that.content=JSON.parse(content);
					that.showContent();
				}});
		
	} else {
		GUI.error('Missing rights','No right to read content on '+this,this);
		return false;
	}	
		
}

ContentObject.getContent=ContentObject.updateContent;

ContentObject.setContent=function(content){
	
	if (this.mayChangeContent()) {
	
		Helper.serverCommand({command:'setContent',
		       room:this.getCurrentRoom(),
		       id:this.getAttribute('id'),
		       data:content,
		       responseFunction:function(){ObjectManager.loadRoom();}
	    });
		
	} else {
		GUI.error('Missing rights','No right to change content on '+this,this);
		return false;
	}
	
}

ContentObject.getContent = function() {
	return this.content;
}

ContentObject.showContent=function(){
	//undefined;
}

ContentObject.hasContent=function(){
	return this.contentAge != 0;
}