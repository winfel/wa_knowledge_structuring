<?php

//TODO: content-type

$connector->registerCommand('getRawContent',function() use($connector) {
		$id=$connector->getId();
		if (!$id){$connector->error($connector::ERROR_MISSING_ID,'Missing object id');}
		
		$room=$connector->getRoom();
		if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
		
		$content=$connector->get($room,$id,'content');
		$obj=$connector->getAttributes($room,$id);
		
		$mimeType=(isset($obj['mimeType']))?$obj['mimeType']:'text/plain';
		
		header('Content-Type: '.$mimeType);
		if (isset($obj['name'])) header('Content-Disposition: attachment; filename="' .$obj['name'] .'"');
		//system ('say get raw content');
		die ($content);
});

$connector->registerCommand('getContent',function() use($connector) {
		$id=$connector->getId();
		if (!$id){$connector->error($connector::ERROR_MISSING_ID,'Missing object id');}
		
		$room=$connector->getRoom();
		if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
		
		$content=$connector->get($room,$id,'content');
		
		if (!$content) {$connector->error($connector::ERROR_MISSING_CONTENT,'This object does not have a content yet!');}
		
		$connector->response($content);
});

$connector->registerCommand('setContent',function() use($connector) {
		$id=$connector->getId();
		if (!$id){$connector->error($connector::ERROR_MISSING_ID,'Missing object id');}
		
		$room=$connector->getRoom();
		if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
		
		$content=$connector->getData();
		
		if (stripos($content,'ata:image/png;base64,')){ // Handling of Encoded png-files
			$content=str_replace('data:image/png;base64,','',$content);
			$content = str_replace(" ","+",$content);
			$content=base64_decode($content);
			$connector->setAttibute($room,$id,'mimeType','image/png');
		}
		
		if ($connector->set($room,$id,'content',$content)) {
			$connector->response('success');
		} else {
			$connector->error($connector::ERROR_NO_WRITE_RIGHT,'Cannot write to the room.');
		};
		
		
});

$connector->registerCommand('uploadContent',function() use($connector) {
		$id=$connector->getId();
		if (!$id){$connector->error($connector::ERROR_MISSING_ID,'Missing object id');}
		
		$room=$connector->getRoom();
		if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
			
		$file=$_FILES['file'];
		
		if (!$file) {$connector->error($connector::ERROR_MISSING_DATA,'Did not provide a file!');}
		
		$error=$file['error'];
		
		if ($error){
			{$connector->error($connector::ERROR_UPLOAD_FAILED,'Upload failed with code '+$error);}
		} else {
	
			$local=$file['tmp_name'];
			$mime=$file['type'];
			
			$connector->set($room,$id,'content',(file_get_contents($local)));
			$connector->setAttibute($room,$id,'mimeType',$mime);
			
			
		}
});

?>