
ContentObject.setTranslations('de',{
	'ContentObject':'Inhaltsobjekt',
	'contentAge':'Inhaltsalter',
	'mimeType':'Dateityp'
}
);
