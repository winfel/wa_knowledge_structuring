Rectangle.setTranslations('de',{
	'Rectangle':'Rechteck'
}
);
