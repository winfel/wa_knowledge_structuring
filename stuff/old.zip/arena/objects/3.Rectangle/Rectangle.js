/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var Rectangle=Object.create(GraphicalObject);

Rectangle.register('Rectangle');
Rectangle.isCreatable=true;