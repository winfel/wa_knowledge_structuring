/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/


Ellipse.createRepresentation = function() {
	
	rep = GUI.svg.ellipse(
		10, //cx
		10, //cy
		10, //rx
		10 //ry
	);

	rep.dataObject=this;

	$(rep).attr("id", this.getAttribute('id'));

	this.initGUI(rep);
	
	return rep;
	
}


Ellipse.draw=function(){
	
	var rep=this.getRepresentation();
	
	GraphicalObject.draw.call(this);

	$(rep).attr("fill", this.getAttribute('fillcolor'));
	$(rep).attr("stroke", this.getAttribute('linecolor'));
	$(rep).attr("stroke-width", this.getAttribute('linesize'));
	

}


/* view getter */

Ellipse.getViewX = function() {
	return parseInt($(this.getRepresentation()).attr("cx").toString(), 10);
}

Ellipse.getViewY = function() {
	return parseInt($(this.getRepresentation()).attr("cy").toString(), 10);
}

Ellipse.getViewWidth = function() {
	return parseInt($(this.getRepresentation()).attr("rx").toString(), 10);
}

Ellipse.getViewHeight = function() {
	return parseInt($(this.getRepresentation()).attr("ry").toString(), 10);
}

Ellipse.getViewBoundingBoxX = function() {
	return this.getViewX()-this.getViewWidth();
}

Ellipse.getViewBoundingBoxY = function() {
	return this.getViewY()-this.getViewHeight();
}

Ellipse.getViewBoundingBoxWidth = function() {
	if (this.hasAttribute('linesize')) {
		var linesize = this.getAttribute('linesize')/2;
	} else {
		var linesize = 0;
	}
	return this.getViewWidth()*2+linesize;
}

Ellipse.getViewBoundingBoxHeight = function() {
	if (this.hasAttribute('linesize')) {
		var linesize = this.getAttribute('linesize')/2;
	} else {
		var linesize = 0;
	}
	return this.getViewHeight()*2+linesize;
}

/* view setter */

Ellipse.setViewX = function(value) {
	$(this.getRepresentation()).attr("cx", parseInt(value));
	GUI.adjustContent(this);
}

Ellipse.setViewY = function(value) {
	$(this.getRepresentation()).attr("cy", parseInt(value));
	GUI.adjustContent(this);
}

Ellipse.setViewWidth = function(value) {
	$(this.getRepresentation()).attr("rx", parseInt(value));
	GUI.adjustContent(this);
}

Ellipse.setViewHeight = function(value) {
	$(this.getRepresentation()).attr("ry", parseInt(value));
	GUI.adjustContent(this);
}





/*
Ellipse.hasPixelAt=function(x,y){
	
	if (!this.boxContainsPoint(x,y)) return false;
	
	x=x-this.getAttribute('x');
	y=y-this.getAttribute('y');
	
	
	var canvasId=this.data.id+'canvas1';
	var canvas  = document.getElementById(canvasId);			
    var context = canvas.getContext('2d');
    
    try {
	 var imageData=context.getImageData(x, y, 1,1);
    } catch(err) {
    	return false;
    }
	
	var alpha = imageData.data[3];
	
	return alpha;
}
*/