/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var Ellipse=Object.create(GraphicalObject);
	
Ellipse.register('Ellipse');
Ellipse.isCreatable=true;
