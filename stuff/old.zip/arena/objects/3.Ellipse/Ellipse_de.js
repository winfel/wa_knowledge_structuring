
Ellipse.setTranslations('de',{
	'Ellipse':'Ellipse'
}
);
