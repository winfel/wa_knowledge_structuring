
Polygon.setTranslations('de',{
	'Polygon':'Vieleck',
	'edges':'Ecken',
	'rotation':'Drehung'
}
);
