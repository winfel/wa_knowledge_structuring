/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var Polygon=Object.create(GraphicalObject);


Polygon.register=function(type){
	
	// Registering the object
	
	GraphicalObject.register.call(this,type);
	
	// Registering attributes circle

	this.registerAttribute('edges',{type:'number',standard:6,min:3,category:'Appearance'});
	this.registerAttribute('rotation',{type:'number',standard:0,min:0,category:'Appearance'});

}

Polygon.register('Polygon');
Polygon.isCreatable=true;
