/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

Polygon.draw=function(){
	
	var rep=this.getRepresentation();
	
	GraphicalObject.draw.call(this);

	$(rep).attr("fill", this.getAttribute('fillcolor'));
	$(rep).attr("stroke", this.getAttribute('linecolor'));
	$(rep).attr("stroke-width", this.getAttribute('linesize'));
	
	
	
	
	var edges = this.getAttribute("edges");
	
	var angle = 360/edges;
	
	this.points = [];
	var pointsString = "";
	
	var width = this.getAttribute("width");
	var height = this.getAttribute("height");
	
	var rotation = this.getAttribute("rotation")/180*Math.PI;
	
	for (var i=0; i < edges; i++) {
		
		var x = width*Math.cos(2*Math.PI*(i/edges)+rotation);
		var y = height*Math.sin(2*Math.PI*(i/edges)+rotation);
		
		this.points.push([x,y]);
		pointsString += x+","+y+" ";
		
	}
	
	$(rep).attr("points", pointsString);

}



Polygon.createRepresentation = function() {
	
	this.points = [];

	rep = GUI.svg.polyline(this.points);



	rep.dataObject=this;

	$(rep).attr("id", this.getAttribute('id'));
	
	$(rep).attr("moveByTransform", "true");

	this.initGUI(rep);
	
	return rep;
	
}








/* view getter */

Polygon.getViewBoundingBoxX = function() {
	return this.getViewX()-this.getViewWidth();
}

Polygon.getViewBoundingBoxY = function() {
	return this.getViewY()-this.getViewHeight();
}

Polygon.getViewBoundingBoxWidth = function() {
	if (this.hasAttribute('linesize')) {
		var linesize = this.getAttribute('linesize')/2;
	} else {
		var linesize = 0;
	}
	return this.getViewWidth()*2+linesize;
}

Polygon.getViewBoundingBoxHeight = function() {
	if (this.hasAttribute('linesize')) {
		var linesize = this.getAttribute('linesize')/2;
	} else {
		var linesize = 0;
	}
	return this.getViewHeight()*2+linesize;
}


