
FileObjectSharepoint.setTranslations('de',{
	'FileObjectSharepoint':'Sharepoint-Datei',
	'reference':'Referenz'
}
);
