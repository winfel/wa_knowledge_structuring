/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var FileObjectSharepoint=Object.create(ContentObject);

FileObjectSharepoint.isCreatable=true;


FileObjectSharepoint.register=function(type){
	
	// Registering the object
	
	ContentObject.register.call(this,type);
	this.registerAttribute('reference',{type:'text',standard:'',readonly:false}); //?? TODO: Must this be visible?
	
	this.category='Documents';
	
	this.unregisterAction('to back');
	this.unregisterAction('to front');
	
}

FileObjectSharepoint.register('FileObjectSharepoint');

FileObjectSharepoint.execute=function(){
	
	var reference=this.getAttribute('reference');
	
	var that=this;
	if (!reference) {
		this.fireEvent('uploadFileSharepoint',{explanation:'Bitte eine Datei auswählen:'});
	} else {
		window.location.href=this.getContentURL();
	}

}

FileObjectSharepoint.justCreated=FileObjectSharepoint.execute;

FileObjectSharepoint.getContentURL=function(){
	return '../server/studiolo/sharepoint/get.php?name='+this.getAttribute('reference');
}

FileObjectSharepoint.isResizable=function(){
	return false;
}