/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

FileObjectSharepoint.draw=function(){
	
	GraphicalObject.draw.call(this);
	
	var rep=this.getRepresentation();
	
	var reference=this.getAttribute('reference');
	
	if (!reference){
		rep.innerHTML='There is no file data yet. Doubleclick to load a file!';
	} else {
		
		GUI.setStyle(text, 'width', '50px');
		GUI.setStyle(text, 'height', 'auto');
		GUI.setStyle(text, 'paddingTop', '40px');
		GUI.setStyle(text, 'fontSize', '12px');
		GUI.setStyle(text, 'textAlign', 'center');
		GUI.setStyle(text, 'zIndex', 2000);
		GUI.setStyle(text, 'background', 'transparent url('+this.iconPath+') 50% 0 no-repeat');
		GUI.setStyle(text, 'border', 'none');
		
		
		rep.innerHTML=this.getAttribute('name');
	}
	
}

FileObjectSharepoint.showContent=function(){
	this.draw();
}
