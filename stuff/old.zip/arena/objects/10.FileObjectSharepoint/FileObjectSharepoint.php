<?php

/*override*/
$connector->registerCommand('delete',function() use($connector) {
		$objects=$connector->getData();
		$room=$connector->getRoom();
		
		if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
		if (!$objects){$connector->error($connector::ERROR_MISSING_DATA,'Missing object ids for deletion');}
		
		foreach ($objects as $id){
			$type=$connector->getAttribute($room,$id,'type');
			if ($type=='FileObjectSharepoint'){     									//untested
				require_once('../../server/studiolo/sharepoint/sharepoint.class.php');
				system ('say Dies ist ein '.$type);
				$name=trim($connector->getAttribute($room,$id,'name'), "\\\"");
				
				$sharepoint = new sharepoint("projects.uni-paderborn.de", "oberhoff", base64_decode('YQ==') . base64_decode('bg==') . base64_decode('KA==') .base64_decode('Tw==') . base64_decode('KQ==') . base64_decode('bg==') . base64_decode('YQ==') . base64_decode('MQ=='));
				try {
					$sharepoint->delete("/websites/studiolo/studiolo/webarena/" .$name);
				} catch (Exception $e) {
		    		error_log('Sharepoint Error: '.  $e->getMessage());
				}
			}
			$connector->delete($room,$id);
		}
		
		$connector->response('Finished');
	
});

$connector->registerCommand('uploadContentSharepoint',function() use ($connector){	//untested
		$id=$connector->getId();
		if (!$id){$connector->error($connector::ERROR_MISSING_ID,'Missing object id');}
		
		$room=$connector->getRoom();
		if (!$room){$connector->error($connector::ERROR_MISSING_ROOM,'Missing room id');}
			
		$file=$_FILES['file'];
		
		if (!$file) {$connector->error($connector::ERROR_MISSING_DATA,'Did not provide a file!');}
		
		$error=$file['error'];
		
		if ($error){
			{$connector->error($connector::ERROR_UPLOAD_FAILED,'Upload failed with code '+$error);}
		} else {
	
			$name=$file['name'];
			$local=$file['tmp_name'];
			
			$sharepoint = new sharepoint("projects.uni-paderborn.de", "oberhoff", base64_decode('YQ==') . base64_decode('bg==') . base64_decode('KA==') .base64_decode('Tw==') . base64_decode('KQ==') . base64_decode('bg==') . base64_decode('YQ==') . base64_decode('MQ=='));
			$filedata = file_get_contents($local);
			try {
				$sharepoint->put("/websites/studiolo/studiolo/webarena/" .$name, $filedata);
			} catch (Exception $e) {
    			error_log('Sharepoint Error: '.  $e->getMessage());
			}
			
		}
});

?>