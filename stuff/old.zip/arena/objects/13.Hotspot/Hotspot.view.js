/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/
			

Hotspot.draw=function(){

	var rep=this.getRepresentation();
	
	GraphicalObject.draw.call(this);

	$(rep).attr("fill", this.getAttribute('fillcolor'));
	$(rep).attr("stroke", this.getAttribute('linecolor'));
	$(rep).attr("stroke-width", this.getAttribute('linesize'));

}