/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var Hotspot=Object.create(GraphicalObject);

Hotspot.register('Hotspot');
Hotspot.category='Lernstatt';
Hotspot.isCreatable=true;

Hotspot.registerAttribute('reference',{type:'object_id',standard:'',category:'Functionality'});
Hotspot.registerAttribute('width',{hidden:true,readonly:false,min:90,max:90,standard:90});
Hotspot.registerAttribute('height',{hidden:true,readonly:false,min:84,max:84,standard:84});

Hotspot.onEnter=function(who){
	//debug (who+' entered '+this);
	ObjectManager.getObject(this.getAttribute('reference')).unHide();
	
	var objects=(ObjectManager.getObjects());	
	
	for (var i in objects){
		var hotspot=objects[i];
		if (hotspot==this) continue;
		if(hotspot.type!=='Hotspot') continue;
		
		hotspot.onLeave();
	}

	
}

Hotspot.onLeave=function(who){
	//debug (this+' was left by '+who); 
	ObjectManager.getObject(this.getAttribute('reference')).hide();	
}


Hotspot.isResizable=function(){
	return false;
}