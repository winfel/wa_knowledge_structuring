Hotspot.setTranslations('de',{
	'Hotspot':'Aktive Fläche'
}
);
