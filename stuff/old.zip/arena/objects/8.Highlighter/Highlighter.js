/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var Highlighter=Object.create(Paint);

Highlighter.isCreatable=true;

Highlighter.register=function(type){
	
	// Registering the object
	
	Paint.register.call(this,type);
	
	this.category='Highlighters';

}


Highlighter.register('Highlighter');


Highlighter.justCreated=function(){

	this.setAttribute("x", 0);
	this.setAttribute("y", 0);

	GUI.editPaint(this, true);
	
}

Highlighter.execute=function(){

	GUI.editPaint(this, true);
	
}