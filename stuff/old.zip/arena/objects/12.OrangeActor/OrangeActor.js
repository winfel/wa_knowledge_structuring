/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var OrangeActor=Object.create(Actor);

OrangeActor.register('Orange Actor');
OrangeActor.isCreatable=true;
OrangeActor.category='Lernstatt';