Dummy.setTranslations('de',{
	'Dummy':'Dummy',
	'Pointer':'Zeiger'
}
);