/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

var Dummy=Object.create(GraphicalObject);

Dummy.register('Dummy');
Dummy.isCreatable=true;
Dummy.category='Pointer';