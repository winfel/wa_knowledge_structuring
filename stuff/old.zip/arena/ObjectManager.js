/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

/**
*	The ObjectManager is a singleton object. It provides access to all objects
*   which are currently availabe as well as functions to create, load or delete
*   them. Object types register themselves here.
*/
var ObjectManager=new function(){

	this.currentRoom=false;       // the name of the current room
	this.types={};				       // an object with all the object types
	this.reloadInterval=2000;          // number of ms after which the content is updated
	this.reloader=this.reloadInterval;
	
	this.objects=[];			       // currently loadad objects
	var manager=this;			       // provide access to the ObjectManager 
									   // in all the following functions
	
	this.clientID = new Date().getTime()-1296055327011; // create a "random" client id

	/**
	*	Make the manager "readable" for debugging purposes
	*/
	this.toString=function(){
		return 'ObjectManager ('+this.clientID+')';
	}
	
	/**
	*	Load the room with the specified room id or reload the
	*	current room if no id is specified
	*/
	this.loadRoom=function(roomId){
		
		//Let all pending persist operations proceed
		for (var i=0;i<manager.objects.length;i++){
			var obj=manager.objects[i];
			obj.persistNow();
		}
		
		if (!roomId) roomId=manager.currentRoom.data.id;
		manager.currentRoom.data.id=roomId;
		manager.load();
		
	}
	
	/**
	*	The actual loading of a room
	*/
	this.load=function(){
		
		// Cancel loading if an object is currently moved or resized
		if (manager.moveActive) return;
		if (manager.resizeObject) return;
		
		var roomId= false;
		if (manager.currentRoom) roomId=manager.currentRoom.data.id;
		if (!roomId) {
			roomId='uninitialized';
		}
		
		// Ajax request. Load room data from the server
		var t=new Date().getTime();
		
		//Let all pending persist operations proceed
		for (var i=0;i<manager.objects.length;i++){
			var obj=manager.objects[i];
			obj.persistNow();
		}

		var that=this;
		var loadFunction=function(input){

			//manager.fireEvent('loading');

			// calculate the reload interval. if the loading has taken long, we choose a long interval for the next reload,
			// if loading is fast, we can reload often
			var t2=new Date().getTime();
			var newInterval=(t2-t)*60;
			if (newInterval<3000) newInterval=3000;
			if(newInterval!=manager.reloadInterval) {
				//manager.reloadInterval=newInterval;
				manager.reloadInterval=2000;
			}
			
			for (var i=0;i<manager.objects.length;i++){
				var obj=manager.objects[i];
				obj.removeFlag=true;
			}
			
			var objects=JSON.parse(input);
			
			rights=objects.rights;
			roomData=objects.room;
			room=Object.create(Room);
			room.data=roomData;
			that.currentRoom=room;
			objects=objects.inventory;
			
			for (var i=0;i<objects.length;i++){
				var entry=objects[i];
				var obj=manager.getObject(entry.id);
				if (!obj){
					obj=manager.addObject(entry.type,entry.id);
				}
				obj.data=entry;
				
				if (obj.data.createdBy==manager.clientID && !obj.justCreatedCalled) {  // if we have just created this object, we call justCreated();
					obj.justCreated();
					obj.justCreatedCalled=true;
					delete (obj.data['createdBy']);
				}
				
				obj.data.toString=(new DataSet).toString;
				
				if (obj.updateContent && entry.contentAge && entry.contentAge!=obj.contentAge){
					obj.updateContent();
				}
				
				obj.removeFlag=false;
				obj.updateGUI();

			}
			
			//Remove objects that are not on the server any more
			var delObjects=[];
			
			for (var i=0;i<manager.objects.length;i++){
				var obj=manager.objects[i];
				if (obj.removeFlag) {
					delObjects.push(obj);
				}
			}
				
			for (var i=0;i<delObjects.length;i++){
				delObjects[i].remove();
			}
			
			updateObjectVector();
			
		};
		
		Helper.serverCommand({command:'load',
                      room:roomId,
                      responseFunction:loadFunction
                     });
	}
	
	this.login=function(user,password){
				Helper.serverCommand({command:'login',
                      data:{
                      	"user":user,
                      	"password":password
                      },
                      responseFunction:alert
                     });
	}
	
	this.logout=function(){
		Helper.serverCommand({command:'logout'});
	}
	
	
	/**
	*	Object types call this to register themselves in the object manager
	*/
	this.registerType=function(type,construct){
		this.types[type]=construct;
		//debug('Registred object type '+type);
	}
	
	/**
	*	get access to the object types object. This object contains the type names as 
	*   key and their prototypes as value.
	*/
	this.getTypes=function(){
		return this.types;
	}
	
	/**
	*	get the prototype of a object type
	*
	*	@param type	the object type as a string
	*/
	this.getPrototype=function(type){
		if (!this.types[type]) return IconObject; //if the object type is not known, we use a general GraphicalObject
		return this.types[type];
	}
	
	/**
	 *   addObject - locally create a new object with a type and an id, add it
	 *   to the data structures and return it. This is only called internally as
	 *   no actual object is created on the server this way.
	 */
	this.addObject=function(intype,id){
		var type=this.getPrototype(intype);
		//debug(intype+' '+type+' '+id);
		var obj=Object.create(type);
		obj.init(id); // the object's init method does the actuar registering of
					  // the objet in the ObjectManager
		return obj;
	}
	
	/**
	 *	createObject - create a new object of a certain type on the server
	 */
	this.createObject=function(type, attributes){
		var proto=this.getPrototype(type);
		if (!proto) return false;
		
		for (var i=0;i<manager.objects.length;i++){
			var obj=manager.objects[i];
			obj.stopOperation();
		}
		
		if (type=='Dummy') return;   // when a "dummy" is created, we do not inform the 
									 // server at all but return immediatelly
		
		var dataSet=proto.standardData;
		dataSet.name=type;
		dataSet.createdBy=this.clientID;  //used to identify newly created elements on load
		
		if (attributes != undefined) {
			$.each(attributes, function(key, value) {
			
				dataSet[key] = value;
				
			});
		}

		Helper.serverCommand({command:'create',
	        room:this.currentRoom.data.id,
	        data:{layer:this.getNextLayer(),type:type,attributes:dataSet},
	        responseFunction:this.load //Perform a reload of the room for immediate response
        });
        //TODO: Error handling
		
	}
	
	/**
	 *  getObject - get an object by it's id. returns the object or false,
	 *  if no object was found
	 */
	this.getObject=function(id){
		
		if (id==this.currentRoom.data.id) return this.currentRoom;
		
		for (var i=0;i<this.objects.length;i++){
			var obj=this.objects[i];
			if ((obj.data.id)===id) return obj;
		}
		return false;
	}
	
	/**
	 *  deleteSelected - deletes the selected objects from the server.
	 */
	this.deleteSelected=function(){
		var selected=this.getSelected();
		var ids=[];
		for (var i in selected){
			selected[i].persistNow();
			ids.push(selected[i].getAttribute('id'));
			
			selected[i].remove();	//remove the objects locally
		}
		
		if (!ids.length) return;   //Do nothing, if there is no selection at all.
		
		Helper.serverCommand({command:'delete',	//remove the objects on the server side
	        room:this.currentRoom.data.id,
	        data:ids,
	        responseFunction:this.load //Perform a reload of the room for immediate response
        });

		this.unselect();
	}	
		
	/**
	 *   updateObjectVector - sorts the object vector by the layers of 
	 *   the object. This must be done after loading, as the server does
	 *   not necessarily care about layer order.
	 */
	function updateObjectVector(){
		var oldObjects=manager.objects;
		var temp1=new Array();
		var temp2=new Array();
		
		for(var i in oldObjects){
			var obj=oldObjects[i];
			var layer=obj.getAttribute('layer');
			if (layer && !temp1[layer]){
				temp1[layer]=obj;
			} else temp2.push(obj);
		}
		
		var newObjects=new Array();
		
		for (var i in temp1){
			if (temp1[i]) newObjects.push(temp1[i]);
		}
		
		for (var i in temp2){
			if (temp2[i]) newObjects.push(temp2[i]);
		}

		manager.objects=newObjects;
		
		manager.updateLayers();
		
	}
	
	/**
	 *	update the layers of the object so that the layer represents the
	 *  order within the object array.
	 */
	this.updateLayers = function(){
	
		for(var i=0;i<manager.objects.length;i++){
			var obj=manager.objects[i];
			if (obj.setLayer) obj.setLayer(i+1);
		}
	
	}


	
	/**
	 *   //TODO DOES THIS BELONG HERE? WHERE DO WE USE IT? 
	 */
	this.setResizeObject=function(obj){
		this.resizeObject=obj;
	}
	
	/**
	 * get an array of all currently selected elements
	 */
	this.getSelected=function(){
			
		var result=[];
		for (var i=0;i<this.objects.length;i++){
			var obj=this.objects[i];
			if (obj.isSelected()) {
				result.push(obj);
			}
		}

		return result;
	}
	
	this.getSelection=this.getSelected;
	
	
	this.getActionsForSelected = function() {
		
		var selectedObjects = this.getSelected();

		var actions = new Array();
		
		$.each(selectedObjects, function(key, object) {
			
			var objActions = new Array();
			
			$.each(object.getActions(), function(actionName, actionData) {
				
				if (!actionData.single || selectedObjects.length == 1) {
					objActions.push(actionName);
				}
				
			});

			actions = Helper.getIntersection(actions, objActions);

		});
		
		return actions;
		
	}
	
	
	this.performActionForSelected = function(actionName) {
		
		var selectedObjects = this.getSelected();
		
		if (!selectedObjects) return;
		
		selectedObjects[0].performAction(actionName);
		
	}
	
	
	/**
	 * getObjects - get an array of all objects
	 */
	this.getObjects=function(){
		return this.objects;
	}
	
	/**
	*	hasObject - determine, if an object is within the current inventory
	*/
	this.hasObject=function(obj){
		return !!this.getObject(obj.getAttribute('id'));
	}
	
	/**
	 * add - add an object to the list of objects. This is only called internally.
	 */
	this.add=function(object){
		this.objects.push(object);
	}
	
	/**
	 * remove - remove a given object from the list of objects. This is only called
	 *			internally, because the object will not be deleted from the server here
	 */
	this.remove=function(object){
		
		var newObjects=[];
		
		for (var i=0;i<this.objects.length;i++){
			if (this.objects[i]!==object) newObjects.push(this.objects[i]);
		}
		
		//TODO updat layers
		
		this.objects=newObjects;
		
	}
	
	/**
	 * getNextLayer - get the layer for a new object whicht should always be created on top
	 */
	this.getNextLayer=function(){
		return this.objects.length+1;
	}
	
	/**
	 * resetReloadCountdown - reset the reload countdown
	 */
	this.resetReloadCountdown=function(){
		manager.reloader=manager.reloadInterval;
	}
	
	this.resetReloadCounter=this.resetReloadCountdown;
	
	/**
	 * reloadCountdown - decrease the reloadcountdown by 1000 every secund. If the countdown 
	 *                   reaches 0 or less, or a lower reload interval is calculated, reset the
	 *					 countdown.
	 * 
	 */
    this.reloadCountdown=function(){
    	
    	//debug (manager.reloader+' of '+manager.reloadInterval);
    	
    	if (manager.reloader>manager.reloadInterval){
    		manager.resetReloadCountdown();            //new smaller reload Interval
    		return;
    	}
    	
    	manager.reloader-=1000;
    	
    	if (manager.reloader<=0){					   //countdown is over
    		manager.resetReloadCountdown();
    		manager.load(); 
    		return;
    	}

    }

	this.getCurrentRoom=function() {
		return this.currentRoom;
	}
        
        this.getCurrentRoomId = function() {
            return this.currentRoom.data.id;
        }
    
	window.setInterval(this.reloadCountdown,1000); //Update the reload countdown every second

}