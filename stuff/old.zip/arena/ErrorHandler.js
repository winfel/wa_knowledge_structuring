/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

errorDisabled = new Array();
errorActive = false;

errorHandler = function(message) {
    
    if ($.inArray(message, errorDisabled) == -1 && errorActive == false) {
        errorActive = true;
        
        GUI.dialog('Sorry!', 'Something went wrong :(<br/><br/>'+message, {
            "Reload": function () {
                window.location.href = window.location;
                errorActive = false;
            },
            "Ignore": function () {
                errorDisabled.push(message);
                errorActive = false;
            },
            "Continue": function () {
                errorActive = false;
            }
        } , '200');
    }
    
    error(message);
    
    return true;
}