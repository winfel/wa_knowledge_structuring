/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

if (true) {							//TODO this overrides how object derivation works. Maybe find a function
									//that does not override the native one.
	Object.create = function (o) {
		function F() {}
		F.prototype = o;
		var result= new F();
		result.parent= o;           // allow access to prototype;
		return result;
	};
}

function debug(message){
	
	if (ObjectManager && ObjectManager.GUI && ObjectManager.GUI.debug){
		ObjectManager.GUI.debug(message);
	}
	
	if (parent.window.console && parent.window.console.log) {
	  parent.window.console.log(message);
	  return;
	}	
	
	if (window.console && window.console.log) {
	  window.console.log(message);
	}
}

function error(message){
	if (ObjectManager && ObjectManager.GUI && ObjectManager.GUI.error){
		ObjectManager.GUI.error(message);
	}
	console.log(ObjectManager);
	if (parent.window.console && parent.window.console.error) {
	  parent.window.console.error(message);
	  if (parent.window.console.trace) parent.window.console.trace();
	  return;
	}	
	
	if (window.console && window.console.error) {
	  window.console.error(message);
	  if (window.console.trace) window.console.trace();
	  return;
	}
	
	debug(message);
	
}

    var Helper=new function(){
    	
    	
		/**
		 * assure - assure type security. 
		 *
		 * Test, if a variable is set. If the variable is undefined
		 * an exception is thrown. 
		 *
		 * If a datatype is provided, the variable is checked against 
		 * that type, forcing an exception in case of a wrong type.
		 *
		 * Name is used for debugging purposes
		 **/
		this.assure=function(variable,name,datatype){
	
			if (!name) name='';
	
			if (variable===undefined){
				throw 'missing variable '+name;
			}
			
			if (!datatype) return true;
			
			if (typeof variable!==datatype) {
				throw 'variable '+name+' is not of type '+datatype;
			}
			
			
		}
    	
	   	this.server_query=function(url,query,callback){
			  query=encodeURI(query);
			  var oXmlHttp=zXmlHttp.createRequest();
			  oXmlHttp.open("post",url,true);
			  oXmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	
			    oXmlHttp.onreadystatechange = function (){
			    	if (oXmlHttp.readyState ==4){
			    		if (oXmlHttp.status==200) {
			    			callback(oXmlHttp.responseText);
			    			if (ObjectManager && ObjectManager.GUI) ObjectManager.GUI.notifyOnline();
			    		} 
			            else {
			            	//debug('Ajax-Error! No connection to server!'); 
			            	if (ObjectManager && ObjectManager.GUI) ObjectManager.GUI.notifyOffline();
			            }
			    	}
			    };
	
			  oXmlHttp.send(query);
		}
	   	
	   	this.serverCommand=function(info){
	   		
	   		//debug('Servercommand: '+info);
	   		
	   		var command=info['command'];
	   		var room=info['room'];
	   		var id=info['id'];
	   		var data=info['data'];
	   		var respFunction=info['responseFunction'];
	   		var errorFunction=info['errorFunction'];
	   		
	   	    //debug ('Server-Request: command:'+command+' room:'+room+' id:'+id);
	   		
	   		var querystring='command='+command;
	   		
	   		if (room) querystring+='&room='+room;
	   		if (id) querystring+='&id='+id;
	   		if (data) querystring+='&data='+JSON.stringify(data);
	   		if (!respFunction) respFunction=function(){};
	   		if (!errorFunction) errorFunction=error;
	   		
	   		var theFunction=function(response){
	   			
	   			//debug('Server-Answer: '+response);
	   			
	   			if (response.substring(0,8)=='RESPONSE'){
	   				response=response.substring(9);
	   				respFunction(response);
	   			} else {
	   				errorHandler(response);
	   			}
	   			
	   			
	   		}
	   		
	   		Helper.server_query('../../server/connector.php',querystring,theFunction);
	   		
	   	}
	   	
	   	this.ele=function(element){
	   		return document.getElementById(element);
	   	}
	   	
	   	this.hide=function(element){
	   		this.ele(element).style.display='none';
	   	}
	
	   	this.show=function(element){
	   		this.ele(element).style.display='block';
	   	}
	   	
	   	this.getRandom=function( min, max ) {
			if( min > max ) {
				return( -1 );
			}
			if( min == max ) {
				return( min );
			}
		 
		        return( min + parseInt( Math.random() * ( max-min+1 ) ) );
		}
	
		this.getIntersection = function(A, B) {

			if (A.length == 0) {
				return B;
			}

			var all = A;
			all.concat(B);

			var result = new Array();

			$.each(all, function(key, value) {

				if (A.indexOf(value) != -1 && B.indexOf(value) != -1) {
					result.push(value);
				}

			});

			return result;

		}
	   	
	}

function html2entities(input){
	var output='';
	
	for (var i=0;i<input.length;i++){
		var letter=input[i];
		
		switch (letter){
			
			case "<": output+="&lt;"; break;
			case ">": output+="&gt;"; break;
			case "\"": output+="&quot;"; break;
			case "'": output+="&#039;"; break;
			case "&": output+="&amp;"; break;
			default:output+=letter;
		}
		
	}

	return output;
}


