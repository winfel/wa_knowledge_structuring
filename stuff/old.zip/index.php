<html>
<head>
<title>The WebArena project</title>
<style>
	* {font-family:Calibri,sans-serif}
</style>
</head>
<body>
<img src="indexpage/HTML5_Logo_256.png" style="float:right"/>
<img src="indexpage/php_logo.png" style="float:right;clear:right;width:200px;margin:10px 30px 0 0"/>
<img src="indexpage/ECMAScript.png" style="float:right;clear:right;width:200px;margin:10px 30px 0 0"/>

<h1>Welcome to the WebArena project</h1>
<h2>Use the WebArena live:</h2>
<p style="margin-left:30px;"><a href="guis/ipad">iPad GUI</a></p>
<p style="margin-left:30px;"><a href="guis/desktop">Desktop GUI</a></p>
<p>Note: The WebArena ist still in development! Please expect it not to work at any time!</p>
<h2>Lines of Code</h2>
<?php

$cwd= (getcwd());
$filecount=array();
$linecount=array();
$filetotal=0;
$linetotal=0;

countIt($cwd);

echo '<table style="margin-left:30px;">';
echo '<tr><th style="text-align:left">type</th><th style="text-align:right">lines</th><th style="text-align:right">files</th></tr>';
foreach ($filecount as $type=>$files){
	$lines=$linecount[$type];
	$filetotal+=$files;
	$linetotal+=$lines;
	echo '<tr><th style="text-align:left">'.$type.'</th><td style="text-align:right">'.$lines.'</td><td style="text-align:right">'.$files.'</td></tr>';
}
echo '<tr><th>total &nbsp;&nbsp;</th><td style="text-align:right">'.$linetotal.'</td><td style="text-align:right">'.$filetotal.'</td></tr>';
echo '</table>';

function countIt($folder){global $filecount,$linecount;
	$items=scandir($folder);
	foreach ($items as $item){
		if ($item[0]=='.') continue;      // Do not care about .svn etc.
		$newPath=$folder.'/'.$item;
		if (is_dir($newPath)){
			countIt($newPath);
		}
		else {
			$filecount++;
			if (strpos($newPath,'.php')) {
				$filecount['php']++;
				lineCount($newPath,'php');
			}
			if (strpos($newPath,'.js')) {
				$filecount['js']++;
				lineCount($newPath,'js');
			}
			if (strpos($newPath,'.css')) {
				$filecount['css']++;
				lineCount($newPath,'css');
			}
			if (strpos($newPath,'.htm')) {
				$filecount['html']++;
				lineCount($newPath,'html');
			}
		}
	}
}

function lineCount($path,$type){global $linecount;
	$file=file_get_contents($path);
	$file=explode("\n",$file);
 	@$linecount[$type]+=count($file);
}

?>

</body>
</html>