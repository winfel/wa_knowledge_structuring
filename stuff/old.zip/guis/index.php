<?php

	session_name("webarena");
	session_start();

	$users = Array(
		"ernie" => Array(
			"homeroom" => "lehrerzimmer",
			"rights" => Array(
				"sporthalle" => Array(
					"change_attributes" => false,
					"read_attributes" => false,
					"change_content" => false,
					"read_content" => false,
					"evaluate" => false
				),
				"abstellkammer" => Array(
					"change_attributes" => false,
					"read_attributes" => true,
					"change_content" => false,
					"read_content" => true,
					"evaluate" => true
				)
			)
		),
		"bert" => Array(
			"homeroom" => "abstellkammer",
			"rights" => Array(
				"sporthalle" => Array(
					"change_attributes" => false,
					"read_attributes" => true,
					"change_content" => false,
					"read_content" => true,
					"evaluate" => false
				),
				"lehrerzimmer" => Array(
					"change_attributes" => true,
					"read_attributes" => true,
					"change_content" => true,
					"read_content" => true,
					"evaluate" => true
				)
			)
		),
		"samson" => Array(
			"homeroom" => "sporthalle",
			"rights" => Array(
				"abstellkammer" => Array(
					"change_attributes" => false,
					"read_attributes" => false,
					"change_content" => false,
					"read_content" => false,
					"evaluate" => false
				),
				"lehrerzimmer" => Array(
					"change_attributes" => false,
					"read_attributes" => false,
					"change_content" => false,
					"read_content" => false,
					"evaluate" => false
				)
			)
		)
	);
	

	if (isset($_GET['user'])) {
		
		$_SESSION['username'] = $_GET['user'];
		$_SESSION['rights'] = $users[$_GET['user']]['rights'];
		$_SESSION['homeroom'] = $users[$_GET['user']]['homeroom'];
		
		header("Location: ".$_GET['gui']."/index.php");
		
	}
	
	if (isset($_GET['logout'])) {
		
		unset($_SESSION['username']);
		unset($_SESSION['rights']);
		unset($_SESSION['homeroom']);
		header("Location: index.php");
		
	}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Select a user</title>
	<style type="text/css" media="screen">
		
		body {
			background-color: #474747;
			font-family: sans-serif;
			font-size: 12px;
		}
		
		.userselection {
			margin-bottom: 40px;
		}
		
		.userselection img {
			border-radius: 10px;
		}
		
		.userselection a {
			text-align: center;
			width: 130px;
			display: block;
			float: left;
			color: #FFFFFF;
			font-size: 15px;
			text-decoration: none;
			margin-right: 40px;
			opacity: 0.6;
		}
		
		.userselection a:hover {
			opacity: 1;
		}
		
		.userselection a span {
			font-size: 11px;
		}
		
		h1 {
			clear: both;
			color: #FFFFFF;
		}
		
	</style>
</head>
<body>

	<h1>Desktop</h1>

	<div class="userselection">
		
		<a href="index.php?user=ernie&gui=desktop"><img src="userselection_images/1.jpg" alt="" /><br />Ernie<br />
		<span>Wohnt im Lehrerzimmer, darf nicht in die Sporthalle und in der Abstellkammer nur lesen</span></a>
		
		<a href="index.php?user=bert&gui=desktop"><img src="userselection_images/2.jpg" alt="" /><br />Bert<br />
		<span>Wohnt in der Abstellkammer, darf in der Sporthalle nur zusehen und im Lehrerzimmer alles</span></a>

		<a href="index.php?user=samson&gui=desktop"><img src="userselection_images/3.jpg" alt="" /><br />Samson<br />
		<span>Wohnt in der Sporthalle, darf nicht in Abstellkammer und Lehrerzimmer</span></a>
		
		<br style="clear: both;" />
	</div>
	
	<h1>iPad</h2>
		
	<div class="userselection">

		<a href="index.php?user=ernie&gui=ipad"><img src="userselection_images/1.jpg" alt="" /><br />Ernie<br />
		<span>Wohnt im Lehrerzimmer, darf nicht in die Sporthalle und in der Abstellkammer nur lesen</span></a>
		
		<a href="index.php?user=bert&gui=ipad"><img src="userselection_images/2.jpg" alt="" /><br />Bert<br />
		<span>Wohnt in der Abstellkammer, darf in der Sporthalle nur zusehen und im Lehrerzimmer alles</span></a>

		<a href="index.php?user=samson&gui=ipad"><img src="userselection_images/3.jpg" alt="" /><br />Samson<br />
		<span>Wohnt in der Sporthalle, darf nicht in Abstellkammer und Lehrerzimmer</span></a>

		<br style="clear: both;" />
	</div>

</body>
</html>
