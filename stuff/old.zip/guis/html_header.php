<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Webarena</title>
<script type="text/javascript" src="../../arena/libraries/jquery/jquery.js"></script>
<script type="text/javascript" src="../../arena/libraries/jquery/plugins/jquery.jPopover.js"></script>

<script type="text/javascript" src="../../arena/libraries/jquery/plugins/jquery.animate-enhanced.min.js"></script>

<script type="text/javascript" src="../../arena/libraries/jquery/plugins/jquery.svg.min.js"></script>
<script type="text/javascript" src="../../arena/libraries/jquery/plugins/jquery.svgdom.min.js"></script>
<script type="text/javascript" src="../../arena/libraries/jquery/plugins/jquery.svgfilter.min.js"></script>

<script type="text/javascript" src="../../arena/libraries/jquery/plugins/jquery.tinysort.min.js"></script>

<link type="text/css" href="style.css" rel="Stylesheet" />

<script type="text/javascript" src="../../arena/libraries/zxml.js.php"></script>

<script type="text/javascript" src="../../arena/ErrorHandler.js?version=<?php echo $version?>"></script>
<script type="text/javascript" src="../../arena/Helper.js?version=<?php echo $version?>"></script>
<script type="text/javascript" src="../../arena/AttributeManager.js?version=<?php echo $version?>"></script>
<script type="text/javascript" src="../../arena/ActionManager.js?version=<?php echo $version?>"></script>
<script type="text/javascript" src="../../arena/TranslationManager.js?version=<?php echo $version?>"></script>
<script type="text/javascript" src="../../arena/ObjectManager.js?version=<?php echo $version?>"></script>
<script type="text/javascript" src="../../arena/DataSet.js?version=<?php echo $version?>"></script>

<?php

	/* load GUI javascript files */
	$files = Array();
	
	$dir = scandir("../javascript");
	
	if ($dir) {
		foreach ($dir as $file) {
			if ($file != ".." AND $file != "." AND strpos($file, ".js") !== false) {
				$files[] = $file;
			}
		}
	}
	
	sort($files);
	
	foreach ($files as $file) {
		echo '<script type="text/javascript" src="../javascript/'.$file.'"></script>'."\n";
	}
	
	
	/* load GUI css files */
	$files = Array();
	
	$dir = scandir("../css");
	
	if ($dir) {
		foreach ($dir as $file) {
			if ($file != ".." AND $file != "." AND strpos($file, ".css") !== false) {
				$files[] = $file;
			}
		}
	}
	
	sort($files);
	
	foreach ($files as $file) {
		echo '<link type="text/css" href="../css/'.$file.'" rel="Stylesheet" />'."\n";
	}

?>

<script type="text/javascript" src="../../arena/libraries/jquery/jquery-ui.js"></script>
<link type="text/css" href="../../arena/libraries/jquery/css/jquery-ui.css" rel="Stylesheet" />

<script type="text/javascript" src="../../arena/libraries/jquery/plugins/jquery.color.js"></script>

<meta http-equiv="content-type" content="text/html; charset=UTF-8">

<script type="text/javascript">

/*
*
*	Loading of javascript modules 
*
*   This is done in alphabetical order. To assure parent objects are loaded
*   before their children are created, start the folder's name with a
*   number. Within each object, all javascript files are included
*   in alphabetical order as well. The main file is included first followed
*   by visual additions or evaluation code.
*
*/

</script>
<?php

$cwd= (getcwd());
$objectsFolder='../../arena/objects';

$objectsDir=$cwd.'/'.$objectsFolder;

$temp=scandir($objectsDir);unset($temp[0]);unset($temp[1]);

$objects=array();

$n=0;
foreach ($temp as $object){
	$n++;
	if ($object[0]=='.') continue;      // Do not care about .svn etc.
	$data=explode('.',$object);
	if (!isset($data[1])) continue;
	$index=$data[0]*1000+$n;
	$objects[$index]=$object;
}

ksort($objects);

foreach ($objects as $object){
    $data=explode('.',$object);
	$objectName=$data[1];
	$objectFolder=$objectsFolder.'/'.$object;
	$objectPath=$cwd.'/'.$objectFolder;
	$files=scandir($objectPath);
	foreach ($files as $file){
		if (!stripos($file,'.js')) continue;
		echo '<script type="text/javascript" src="'.$objectFolder.'/'.$file.'?version='.$version.'"></script>';
	}
	echo '<script type="text/javascript">
	         '.$objectName.'.objectPath="'.$objectFolder.'";'.'
	         '.$objectName.'.iconPath="'.$objectFolder.'/icon.png";'.'
	      </script>'; //tell the object its own path
}

?>