/* paint */

GUI.paintModeActive = false;



GUI.setPaintColor = function(color, colorName) {
	GUI.paintColor = color;
	GUI.setPaintCursor(colorName);
	GUI.paintEraseModeActive = false;
}

GUI.setPaintCursor = function(cursorName) {
	GUI.paintCursor = "../images/paint/cursors/"+cursorName+".png";
}

GUI.setPaintSize = function(value) {
	GUI.paintSize = value;
	GUI.paintEraseModeActive = false;
}


GUI.paintColors = [];
GUI.paintSizes = [];


GUI.resetPaintColors = function() {
	GUI.paintColors = [];
}

GUI.resetPaintSizes = function() {
	GUI.paintSizes = [];
}

GUI.addPaintColor = function(color, colorName) {
	if (colorName == undefined) {
		colorName = color;
	}
	GUI.paintColors.push([color,colorName]);
}

GUI.addPaintSize = function(size) {
	GUI.paintSizes.push(size);
}

GUI.editPaint = function(webarenaObject, highlighterMode) {

	GUI.currentPaintObject = webarenaObject;

	GUI.painted = false;

	GUI.paintModeActive = true;

	GUI.saveInspectorStateAndHide();

	
	$("#header > div.header_left").children().hide();
	$("#header > div.header_right").children().hide();
	
	
	GUI.resetPaintColors();
	
	if (highlighterMode) {
		GUI.addPaintColor("#f6ff00", "yellow");
		GUI.setPaintColor("#f6ff00", "yellow");
		GUI.setPaintSize(20);
	} else {
		GUI.addPaintColor("#000000", "black");
		GUI.setPaintColor("#000000", "black");
		GUI.setPaintSize(3);
	}
	
	GUI.addPaintColor("red");
	GUI.addPaintColor("green");
	GUI.addPaintColor("blue");
	
	GUI.resetPaintSizes();
	
	if (!highlighterMode) {
	
		GUI.addPaintSize(1);
		GUI.addPaintSize(3);
		GUI.addPaintSize(7);
	
	}
	
	GUI.addPaintSize(14);
	GUI.addPaintSize(20);
	GUI.addPaintSize(24);
	
	
	/* add color selection */
	
	$.each(GUI.paintColors, function(index, color) {
	
		var colorSelection = document.createElement("img");
		$(colorSelection).attr("src", "../images/paint/colors/"+color[1]+".png");
		$(colorSelection).addClass("jPaint_navi");
		$(colorSelection).bind("click", function(event) {
			GUI.setPaintColor(color[0], color[1]);
		});

		$("#header > div.header_left").append(colorSelection);
		
	});
	
	
	/* add size selection */
	
	$.each(GUI.paintSizes, function(index, size) {
		
		var sizeSelection = document.createElement("img");
		$(sizeSelection).attr("src", "../images/paint/sizes/"+size+".png");
		$(sizeSelection).addClass("jPaint_navi");
		$(sizeSelection).bind("click", function(event) {
			GUI.setPaintSize(size);
		});

		$("#header > div.header_left").append(sizeSelection);
		
	});
	
	

	/* add eraser selection */
	
	var eraser = document.createElement("img");
	$(eraser).attr("src", "../images/paint/eraser.png");
	$(eraser).addClass("jPaint_navi");
	$(eraser).bind("click", function(event) {
		GUI.setPaintCursor("eraser");
		GUI.paintEraseModeActive = true;
	});

	$("#header > div.header_left").append(eraser);



	/* add cancel button */
	var cancelButton = document.createElement("span");
	$(cancelButton).addClass("header_button");
	$(cancelButton).addClass("jPaint_navi");
	$(cancelButton).html(GUI.translate("cancel"));
	$(cancelButton).bind("click", function(event) {
		GUI.cancelPaintMode();
	});

	$("#header > div.header_right").append(cancelButton);
	
	
	/* add save/close button */
	var closeButton = document.createElement("span");
	$(closeButton).addClass("header_button");
	$(closeButton).addClass("jPaint_navi");
	$(closeButton).html(GUI.translate("save"));
	$(closeButton).bind("click", function(event) {
		GUI.closePaintMode();
	});

	$("#header > div.header_right").append(closeButton);
	
	$("#header img").css("opacity", 1);
	
	
	/* create html canvas */
	GUI.paintCanvas = document.createElement("canvas");
	
	var svgpos = $("#content").offset();
	
	/* align canvas */
	$(GUI.paintCanvas).css("position", "absolute");
	$(GUI.paintCanvas).css("top", svgpos.top);
	$(GUI.paintCanvas).attr("width", $("#content").width());
	$(GUI.paintCanvas).attr("height", $("#content").height()-svgpos.top);
	$(GUI.paintCanvas).css("z-index", 10000);
	$(GUI.paintCanvas).attr("id", "webarena_paintCanvas");
	
	var rep = webarenaObject.getRepresentation();
	
	if (highlighterMode) {
		$(GUI.paintCanvas).css("opacity", $(rep).attr("normalOpacity"));
	}
		
	$("body").append(GUI.paintCanvas);
	
	
	if (highlighterMode != true) {

		/* set lower opacity to all objects */
		$.each(ObjectManager.getObjects(), function(index, object) {
			$(object.getRepresentation()).css("opacity", 0.4);
		});
	
	}
	
	/* hide this object */
	$(rep).css("opacity", 0);
	
	
	/* load content */
	if (webarenaObject.hasContent()) {
		
		var img = new Image();
		
		$(img).bind("load", function() {
			
			var canvasContext = $("#webarena_paintCanvas").get(0).getContext('2d');
			
			var x = webarenaObject.getAttribute("x");
			var y = webarenaObject.getAttribute("y");
			
			canvasContext.drawImage(img, x, y, img.width, img.height);
			
			GUI.paintMinX = x;
			GUI.paintMinY = y;
			GUI.paintMaxX = x+img.width;
			GUI.paintMaxY = y+img.height;
			
		});
		
		var rep = webarenaObject.getRepresentation();
		
		$(img).attr("src", $(rep).attr("href"));
		
	}
	
	
	
	
	$("#webarena_paintCanvas").unbind("mousedown.paint"); //unbind old mousedown-event
	
	$("#webarena_paintCanvas").bind("mousedown.paint", function(event) {

		GUI.paintLastPoint = undefined;

		event.preventDefault();
		
		GUI.painted = true;
		
		if (!GUI.paintEraseModeActive) {
		
			var canvasContext = $("#webarena_paintCanvas").get(0).getContext('2d');

			if (GUI.paintHighlighterModeActive) {
				canvasContext.strokeStyle = GUI.highlighterColor;
				canvasContext.lineWidth = GUI.highlighterSize;
			} else {
				canvasContext.strokeStyle = GUI.paintColor;
				canvasContext.lineWidth = GUI.paintSize;
			}
			
			canvasContext.lineCap = "round";
			
			canvasContext.beginPath();
		
			GUI.paintMove(event.pageX, event.pageY);
		
			GUI.paintPaint(event.pageX, event.pageY);
			GUI.paintPaint(event.pageX+1, event.pageY);

		} else {
			GUI.paintErase(event.pageX, event.pageY);
		}

		$("#webarena_paintCanvas").bind("mousemove.paint", function(event) {
			
			event.preventDefault();

			if (!GUI.paintEraseModeActive) {
				GUI.paintPaint(event.pageX, event.pageY);
			} else {
				GUI.paintErase(event.pageX, event.pageY);
			}

		}).bind("mouseup.paint", function(event) {
			
			event.preventDefault();

			$("#webarena_paintCanvas").unbind("mousemove.paint");
			$("#webarena_paintCanvas").unbind("mouseup.paint");

		});
		
	});

	
}


GUI.paintPaint = function(x,y) {

	var svgpos = $("#content").offset();
	y = y-svgpos.top;

	if (GUI.paintLastPoint == undefined) {
		GUI.paintLastPoint = [x,y];
		return;
	}

	var canvasContext = $("#webarena_paintCanvas").get(0).getContext('2d');

	//canvasContext.lineTo(x,y);
	
	var xc = (GUI.paintLastPoint[0] + x) / 2;
	var yc = (GUI.paintLastPoint[1] + y) / 2;
	
	canvasContext.quadraticCurveTo(GUI.paintLastPoint[0], GUI.paintLastPoint[1], xc, yc);
	
	GUI.paintLastPoint = [x,y];
	
	canvasContext.stroke();
	
	/* set min/max */
	if (GUI.paintMaxX == undefined || x > GUI.paintMaxX) {
		GUI.paintMaxX = x;
	}
	if (GUI.paintMaxY == undefined || y > GUI.paintMaxY) {
		GUI.paintMaxY = y;
	}
	if (GUI.paintMinX == undefined || x < GUI.paintMinX) {
		GUI.paintMinX = x;
	}
	if (GUI.paintMinY == undefined || y < GUI.paintMinY) {
		GUI.paintMinY = y;
	}
	
}


GUI.paintMove = function(x,y) {

	var svgpos = $("#content").offset();
	y = y-svgpos.top;

	var canvasContext = $("#webarena_paintCanvas").get(0).getContext('2d');
	
	canvasContext.moveTo(x,y);
	
}

GUI.paintErase = function(x,y) {
	
	var svgpos = $("#content").offset();
	y = y-svgpos.top;

	var eraserSize = 20;
	
	x = x-(eraserSize/2);
	y = y-(eraserSize/2);
	
	var canvasContext = $("#webarena_paintCanvas").get(0).getContext('2d');
	
	canvasContext.clearRect(x, y, eraserSize,eraserSize);
	
}

GUI.cancelPaintMode = function() {
	
	GUI.paintModeActive = false;
	
	$("#content").unbind("mousedown.paint");
	
	GUI.restoreInspectorFromSavedState();
	
	$("#header").find(".jPaint_navi").remove();
	
	$("#header > div.header_left").children().show();
	$("#header > div.header_right").children().show();
	
	$("#header img").css("opacity", 0.6);
	
	$("#webarena_paintCanvas").remove();
	
	/* set normal opacity to all objects */
	GUI.hideHiddenObjects();
	
}

GUI.closePaintMode = function() {
	
	GUI.paintMaxX = GUI.paintMaxX+5;
	GUI.paintMaxY = GUI.paintMaxY+5;
	GUI.paintMinX = GUI.paintMinX-5;
	GUI.paintMinY = GUI.paintMinY-5;
	
	var width = GUI.paintMaxX-GUI.paintMinX;
	var height = GUI.paintMaxY-GUI.paintMinY;
	
	GUI.currentPaintObject.setAttribute("width", width);
	GUI.currentPaintObject.setAttribute("height", height);
	
	GUI.currentPaintObject.setAttribute("x", GUI.paintMinX);
	GUI.currentPaintObject.setAttribute("y", GUI.paintMinY);
	
	var canvasContext = $("#webarena_paintCanvas").get(0).getContext('2d');
	
	var img = canvasContext.getImageData(GUI.paintMinX,GUI.paintMinY,width,height);

	$("#webarena_paintCanvas").attr("width", width);
	$("#webarena_paintCanvas").attr("height", height);
	
	canvasContext.putImageData(img,0,0);
	
	GUI.currentPaintObject.setContent($("#webarena_paintCanvas").get(0).toDataURL());
	GUI.currentPaintObject.draw();
	
	GUI.cancelPaintMode();
	
}