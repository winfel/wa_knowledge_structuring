$(function() {

	ObjectManager.load();
	
	/* insert icons for creating new objects: */
	
	var types = {};
	
	$.each(ObjectManager.getTypes(), function(key, object) { 
	
		if (object.isCreatable) {
			
			if (object.category == undefined) {
				object.category = "default";
			}
			
			if (types[object.category] == undefined) {
				types[object.category] = [];
			}
			
			types[object.category].push(object);
			
		}
	
	});
	
	
	
	$.each(types, function(key, object) { 

		var newCategoryIcon = document.createElement("img");
		$(newCategoryIcon).attr("src", "../images/categories/"+object[0].category+".png").attr("alt", "");
		$(newCategoryIcon).attr("width", "24").attr("height", "24");

		$("#header>div.header_left").append(newCategoryIcon);

		if (object.length > 1) {
			
			/* add Popover */
			
			$(newCategoryIcon).jPopover({
				positionOffsetY : $("#header").height()-7,
				onSetup : function(domEl, popover) {
					
					var page = popover.addPage(GUI.translate(key));
					var section = page.addSection();

					$.each(object, function(key, object) {

						var name = object.translate(GUI.currentLanguage,object.type);

						var element = section.addElement('<img src="'+object.iconPath+'" alt="" width="24" height="24" /> '+name);
						
						element.onClick(function() {

							ObjectManager.createObject(object.type, {
								hidden: GUI.hiddenObjectsVisible
							});
							popover.hide();
							
						});

					});
					
				}
			});
		
		} else {
			
			/* add link to icon (no Popover) */
			
			$(newCategoryIcon).bind("click", function(event) {

				ObjectManager.createObject(object[0].type, {
					hidden: GUI.hiddenObjectsVisible
				});

			});
			
		}
	
	});
	
});