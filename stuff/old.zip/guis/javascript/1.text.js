GUI.editText = function(webarenaObject) {
	
	var style = 'font-family: '+webarenaObject.getAttribute("font-family")+'; ';
	style += 'color: '+webarenaObject.getAttribute("font-color")+'; ';
	style += 'font-size: '+webarenaObject.getAttribute("font-size")+'px;';
	
	GUI.dialog("edit text", '<input type="text" name="textedit" value="'+webarenaObject.getContent()+'" style="'+style+'" />', {
		"save" : function(domContent){
			var value = $(domContent).find("input").attr("value");
			webarenaObject.setContent(value);
		}
	});
	
}