/* hidden objects */

GUI.hiddenObjectsVisible = false;


GUI.hideObject = function(webarenaObject) {

	var rep = webarenaObject.getRepresentation();
	
	if (webarenaObject.getAttribute("hidden")) {
		$(rep).hide();
	} else {
		$(rep).css("opacity", 0.1);
	}
	
}


GUI.showObject = function(webarenaObject) {

	var rep = webarenaObject.getRepresentation();
	
	if (!$(rep).hasClass("webarena_ghost") && !GUI.paintModeActive) {
		
		if ($(rep).attr("normalOpacity") != undefined) {
			$(rep).css("opacity", $(rep).attr("normalOpacity"));
		} else {
			$(rep).css("opacity", 1);
		}
		
	}
	
	$(rep).show();

}


GUI.showHiddenObjects = function() {

	$.each(ObjectManager.getObjects(), function(index, object) {
			
		if (object.getAttribute("hidden")) {
			GUI.showObject(object);
		} else {
			GUI.hideObject(object);
		}
		
	});
	
}


GUI.hideHiddenObjects = function() {

	$.each(ObjectManager.getObjects(), function(index, object) {
			
		if (object.getAttribute("hidden")) {
			GUI.hideObject(object);
		} else {
			GUI.showObject(object);
		}
		
	});
	
}


GUI.toggleHidden = function() {

	GUI.deselectAllObjects();

	if (GUI.hiddenObjectsVisible) {
		/* hide hidden objects */
		
		GUI.hideHiddenObjects();
		GUI.hiddenObjectsVisible = false;
		
		return false;
		
	} else {
		/* show hidden objects */
		
		GUI.showHiddenObjects();
		GUI.hiddenObjectsVisible = true;
		
		return true;
		
	}
	
}