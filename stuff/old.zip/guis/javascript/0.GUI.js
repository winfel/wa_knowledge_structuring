var GUI={};

GUI.currentLanguage='de';


GUI.translationManager=Object.create(TranslationManager);
GUI.translationManager.init(undefined);

GUI.setTranslations=function(language,data){
	return this.translationManager.addTranslations(language, data);
}

GUI.translate=function(text){
	
	return this.translationManager.get(this.currentLanguage, text);
	
}




/* ---> needed!? <--- */
GUI.objectSaved=function(object){
}

GUI.objectRemoved=function(object){
}

GUI.objectSelected=function(object){
}

GUI.objectUnselected=function(object){
}









GUI.updateGUI = function(webarenaObject) {
	
	var rep = webarenaObject.getRepresentation();
	
	if (webarenaObject.getAttribute("hidden")) {
		/* object is hidden */
		if (GUI.hiddenObjectsVisible) {
			GUI.showObject(webarenaObject);
		} else {
			GUI.hideObject(webarenaObject);
		}
	} else {
		/* object is not hidden */
		if (GUI.hiddenObjectsVisible) {
			GUI.hideObject(webarenaObject);
		} else {
			GUI.showObject(webarenaObject);
		}
	}

}






GUI.adjustContent = function(webarenaObject) {
	
	if (webarenaObject != undefined) {
		/* check if new position of webarenaObject needs a new room width/height */
		
		var currentRoom = ObjectManager.getCurrentRoom();
		
		var maxX = webarenaObject.getViewBoundingBoxX()+webarenaObject.getViewBoundingBoxWidth();
		var maxY = webarenaObject.getViewBoundingBoxY()+webarenaObject.getViewBoundingBoxHeight();
		
		if (maxX > currentRoom.getAttribute("width")) {
			currentRoom.setAttribute("width", maxX+100);
			$("#content").css("width", maxX+100);
		}
		
		if (maxY > currentRoom.getAttribute("height")) {
			currentRoom.setAttribute("height", maxY+100);
			$("#content").css("height", maxY+100);
		}
		
	} else {
		/* set room width/height */
		var currentRoom = ObjectManager.getCurrentRoom();
		
		var width = currentRoom.getAttribute("width");
		var height = currentRoom.getAttribute("height");
		
		if (width < $(document).width()) {
			width = $(document).width();
		}
		
		if (height < $(document).height()) {
			height = $(document).height();
		}
		
		$("#content").css("width", width);
		$("#content").css("height", height);
	}
	
}

$(function(){
	
	window.setInterval(function() {
		
		var maxX = 0;
		var maxY = 0;
		
		$.each(ObjectManager.getObjects(), function(index, object) {
		
			var rightX = object.getViewBoundingBoxX()+object.getViewBoundingBoxWidth();
			var bottomY = object.getViewBoundingBoxY()+object.getViewBoundingBoxHeight();
			
			if (rightX > maxX) {
				maxX = rightX;
			}
			
			if (bottomY > maxY) {
				maxY = bottomY;
			}
			
		});
		
		var currentRoom = ObjectManager.getCurrentRoom();
		
		if (maxX < currentRoom.getAttribute("width")) {
			currentRoom.setAttribute("width", maxX+100);
			$("#content").css("width", maxX+100);
		}

		if (maxY < currentRoom.getAttribute("height")) {
			currentRoom.setAttribute("height", maxY+100);
			$("#content").css("height", maxY+100);
		}

	}, 10000);
	
});




GUI.sortObjects = function() {

	window.setTimeout(function() {
		
		$("#content>svg>*").tsort("",{order:"asc",attr:"layer"});
		$("#content>svg>*").tsort("",{order:"asc",attr:"layer"});
		
	}, 1);
	
}




/* object selection */

GUI.deselectAllObjects = function() {
    
        // reset routing hash back to current room
        window.location.hash = '#' + ObjectManager.getCurrentRoomId();
	
	$.each(ObjectManager.getSelected(), function(index, object) {
		object.deselect();
	});
	
}






/* multi selection */

GUI.shiftKeyDown = false;

$(function() {

	$(document).bind("keydown", function(event) {
		
		if (event.keyCode == 16) {
			GUI.shiftKeyDown = true;
		}
		
	});
	
	$(document).bind("keyup", function(event) {
		
		if (event.keyCode == 16) {
			GUI.shiftKeyDown = false;
		}
		
	});
	
});



/* move by keyboard */

GUI.blockKeyEvents = false;

$(function() {

	$(document).bind("keydown", function(event) {
	
		if (GUI.blockKeyEvents) return;
	
		if (GUI.shiftKeyDown) {
			var d = 10;
		} else {
			var d = 1;
		}
	
		$.each(ObjectManager.getSelected(), function(index, object) {
			
			if (event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 38 || event.keyCode == 40) {
				event.preventDefault();
			} else {
				return;
			}
			
			GUI.hideActionsheet();
			
			if (event.keyCode == 37) {
				object.moveBy(d*(-1), 0);
			}
			
			if (event.keyCode == 39) {
				object.moveBy(d, 0);
			}
			
			if (event.keyCode == 38) {
				object.moveBy(0, d*(-1));
			}
			
			if (event.keyCode == 40) {
				object.moveBy(0, d);
			}
			
		});
		
	});
	
});











