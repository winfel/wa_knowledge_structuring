GUI.setTranslations('de',{
	'ping':'pong',
	'Basic':'Basis',
	'Dimensions':'Dimensionen',
	'Appearance':'Aussehen',
	'Graphical Elements':'Grafische Elemente',
	'Paintings':'Zeichnungen'
}
);