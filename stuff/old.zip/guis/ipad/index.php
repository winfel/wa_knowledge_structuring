<?php

session_name("webarena");
session_start();

if (!isset($_SESSION['username'])) header("Location: ../index.php");

/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

$version=time();   // Avoid caching issues during implementation
   
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
	<?php
	
		include "../html_header.php";
	
	?>
	<link type="text/css" href="../../arena/libraries/jquery/plugins/css/jquery.jPopover.ipad.css" rel="Stylesheet" />
	
	<meta content="minimum-scale=1.0, initial-scale=1.0, width=device-width, maximum-scale=1, user-scalable=yes" name="viewport" />
	<meta content="yes" name="apple-mobile-web-app-capable" />
	<link rel="apple-touch-icon" sizes="72x72" href="icon.png" />
	<script>
		
		GUI.uploadFile=function(object,message,command){
			
			alert(this.translate('No Upload on iOS'));
			
		}
	
	
		GUI.setupInspector = function() {
			
			$("#inspector").jPopover({
				onOpen : function(domEl, inspector) {
					
					GUI.setupInspectorContent(inspector);
					 					
				},
				onClose : function(domEl, popover) {
					
				}
			});
			
		}
		
		
		GUI.error = function(heading, message, webarenaObject, fatal) {

			var translate = function(text) {
				if (!webarenaObject) {
					return GUI.translate(text);
				} else {
					return webarenaObject.translate(GUI.currentLanguage, text);
				}
			}

			$("#error_box").show();
			$("#error_bg").show();

			$("#error_box_heading").html(translate(heading));
			$("#error_box_message").html(translate(message));

			if (fatal) {
				$("#error_box_button").html(GUI.translate("Reload"));
			} else {
				$("#error_box_button").html(GUI.translate("Close Dialog"));
			}

			$("#error_box_button").bind("click", function(event) {

				if (fatal) {
					window.location.reload();
				} else {
					$("#error_box").hide();
					$("#error_bg").hide();
				}

			});

			$("#error_box").css("top", $(window).height()/2);
			$("#error_box").css("margin-top", (-1)*($("#error_box").outerHeight()/2));

		}
		
		
		
		
		$(function() {
			window.setTimeout(function() {

				GUI.adjustContent();

				GUI.setupInspector();
				
				$("#hiddenToggle").bind("click", function() {
					
					if (GUI.toggleHidden()) {
						$("#hiddenToggle").attr("src", "hidden_active.png");
						huu.play();
					} else {
						$("#hiddenToggle").attr("src", "hidden.png");
					}
					
				});
				
				var huu = new Audio("");
				$("body").append(huu);
				
				huu.src = "huu.m4a";

			}, 100);
		});
		
	</script>
</head>
<body>
	
	<div id="header">
		
		<div class="header_right">
			
			<img src="hidden.png" alt="" id="hiddenToggle" height="24" width="24" />
			
			<img src="info.png" alt="" id="inspector" height="24" width="24" />
			
		</div>
		
		<div class="header_left">
		
		</div>
		
	</div>
	

	
	<div id="content">

	</div>
	
	<div id="actionsheet"></div>
	
	<div id="error_bg"></div>
	<div id="error_box">
		
		<div id="error_box_heading"></div>
		<div id="error_box_message"></div>
		<div id="error_box_button"></div>
		
	</div>

</body>
</html>
