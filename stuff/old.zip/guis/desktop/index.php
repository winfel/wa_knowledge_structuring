<?php

session_name("webarena");
session_start();

if (!isset($_SESSION['username'])) header("Location: ../index.php");

/**
*    Webarena - A webclient for responsive graphical knowledge work
*
*    @author Felix Winkelnkemper, University of Paderborn, 2011
*
*/

$version=time();   // Avoid caching issues during implementation
   
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
	<?php
	
		include "../html_header.php";
	
	?>
	
	
	
	<script type="text/javascript" src="../../arena/libraries/jquery/plugins/jquery.jDesktopInspector.js"></script>
	<link type="text/css" href="../../arena/libraries/jquery/plugins/css/jquery.jDesktopInspector.css" rel="Stylesheet" />
	<link type="text/css" href="../../arena/libraries/jquery/plugins/css/jquery.jPopover.desktop.css" rel="Stylesheet" />
	
	<script>
	
		GUI.uploadFile=function(object,message,command){
			
			if (command == undefined) {
				command = "uploadContent";
			}
			
			var uploadDialog = document.createElement("div");
			$(uploadDialog).attr("title", GUI.translate("upload file"));
			$(uploadDialog).html('<p>'+message+'</p>');
			
			var form = document.createElement("input");
			$(form).attr("type", "file");
			
			$(form).bind("change", function() {
			
				var progress = document.createElement("div");
				$(progress).css("margin-top", "10px");
				$(progress).progressbar({
					value: 0
				});

				$(uploadDialog).append(progress);

				var fd = new FormData();
				fd.append("file", form.files[0]);
				fd.append("id", object.getAttribute('id'));
				fd.append("room", object.getCurrentRoom());
				fd.append("command", command);
				
				var xhr = new XMLHttpRequest();
				xhr.upload.addEventListener("progress", function(evt) {
					
					if (evt.lengthComputable) {
						var percentComplete = Math.round(evt.loaded * 100 / evt.total);
						$(progress).progressbar("value", percentComplete);
					} else {
						$(progress).progressbar("destroy");
						$(progress).html("unable to compute progress");
					}
					
				}, false);
				
				xhr.addEventListener("load", function() {
					//upload complete
					$(uploadDialog).dialog("close");
				}, false);
				xhr.addEventListener("error", function() {
					//failed
					alert("failed");
				}, false);
				xhr.addEventListener("abort", function() {
					//canceled
					alert("cancel");
				}, false);
				xhr.open("POST", "../../server/connector.php");
				xhr.send(fd);
				
				var dialogButtons = {};
				dialogButtons[GUI.translate("cancel")] = function() {
					xhr.abort();
					$(this).dialog("close");
				}
				
				$(uploadDialog).dialog("option", "buttons", dialogButtons);
				
			});
			
			$(uploadDialog).append(form);
			
			var dialogButtons = {};
			dialogButtons[GUI.translate("cancel")] = function() {
				$(this).dialog("close");
			}
			
			$(uploadDialog).dialog({
				modal: true,
				resizable: false,
				buttons: dialogButtons
			});
			
		}

		
		
		
		/* inspector */
		
		GUI.updateInspector = function() {
			
			$("#inspector").data("jDesktopInspector").update();
			
		}
		
		
		GUI.saveInspectorStateAndHide = function() {
			
			GUI.inspectorState = ($("#inspector").css("opacity") > 0);
			GUI.hideInspector();
			
		}
		
		
		GUI.restoreInspectorFromSavedState = function() {
			
			if (GUI.inspectorState) {
				GUI.showInspector();
			}
			
		}
		
		
		GUI.hideInspector = function() {
			
			$("#inspector_button").html(GUI.translate("Show inspector"));
			
			$("#inspector").animate({
				opacity: 0
			}, 200, function() {
				$("#inspector").hide();
			});
			
		}
		
		
		GUI.showInspector = function() {
			
			$("#inspector_button").html(GUI.translate("Hide inspector"));
			
			$("#inspector").show();
			$("#inspector").animate({
				opacity: 1
			}, 200);
			
		}
	
		
		GUI.toggleInspector = function() {
			
			if ($("#inspector").css("opacity") > 0) {
				/* close */
				
				GUI.hideInspector();
				
			} else {
				/* open */
				
				GUI.showInspector();
				
			}
			
		}
		
		
		GUI.setupInspector = function() {
			
			$("#inspector").css("opacity", 0);
			$("#inspector").hide();
			
			
			/* add hidden-mode toggle button */
			
			var hiddenButton = document.createElement("span");
			$(hiddenButton).addClass("header_button");
			$(hiddenButton).attr("id", "hidden_button");
			$(hiddenButton).html(GUI.translate("Show hidden objects"));
			
			$(hiddenButton).bind("click", function() {
				
				if (GUI.toggleHidden()) {
					$("#hidden_button").html(GUI.translate("Hide hidden objects"));
					$("#hidden_button").addClass("button_active");
				} else {
					$("#hidden_button").html(GUI.translate("Show hidden objects"));
					$("#hidden_button").removeClass("button_active");
				}
				
			});
			
			$("#header > .header_right").append(hiddenButton);
			
			
			
			/* add inspector toggle button */
		
			var inspectorButton = document.createElement("span");
			$(inspectorButton).addClass("header_button");
			$(inspectorButton).attr("id", "inspector_button");
			$(inspectorButton).html(GUI.translate("Show inspector"));
			
			$(inspectorButton).bind("click", GUI.toggleInspector);
			
			$("#header > .header_right").append(inspectorButton);
			
			
			
			/* add user info */
			
			var userinfo = document.createElement("span");
			$(userinfo).addClass("header_info");
			$(userinfo).css("font-size", "11px");
			$(userinfo).html(GUI.translate("Logged in user")+': <?php echo $_SESSION['username']; ?>&nbsp;&nbsp;&nbsp;<a href="../index.php?logout=1">'+GUI.translate("Logout")+'</a>');
			
			$("#header > .header_right").prepend(userinfo);
			
			
			
			/* add inspector */

			$("#inspector").jDesktopInspector({
				onUpdate : function(domEl, inspector) {

					GUI.setupInspectorContent(inspector);

				}
			});
			
			
			GUI.showInspector();

		}
		
		
		GUI.error = function(heading, message, webarenaObject, fatal) {

			var translate = function(text) {
				if (!webarenaObject) {
					return GUI.translate(text);
				} else {
					return webarenaObject.translate(GUI.currentLanguage, text);
				}
			}		

			var errorButtons = {};
			
			if (fatal) {
				errorButtons[GUI.translate("Reload")] = function() {
					window.location.reload();
				}
			} else {
				errorButtons[GUI.translate("Close Dialog")] = function() {
					$(this).dialog("close");
				}
			}
			
			var heading = translate(heading);
			var message = '<p>'+translate(message)+'</p>';
			
			GUI.dialog(heading, message, errorButtons);

		}
		
		
		/*
		 * heading: string
		 * content: html content of dialog
		 * buttons: object of buttons e.g.:
		 * 			{
		 * 				"title of this button" : function() {
		 * 					//button callback
		 * 				}
		 * 			}
		 */
		GUI.dialog = function(heading, content, buttons, dialogWidth) {
			
			GUI.blockKeyEvents = true;
			
			if (buttons == undefined) {
				
				var buttons = {};
				
				buttons[GUI.translate("close")] = function() {
					//nothing
				}
				
			}
			
			var dialogContent = document.createElement("div");
			$(dialogContent).attr("title", heading);
			$(dialogContent).html(content);

			var buttons2 = {};
			
			$.each(buttons, function(title, callback) {
				
				buttons2[title] = function() {
					callback(dialogContent);
					$(this).dialog("close");
				}
				
			});
			
			if (dialogWidth == undefined) {
				dialogWidth = "auto";
			}
			
			$(dialogContent).dialog({
				modal: true,
				resizable: false,
				buttons: buttons2,
				zIndex: 100000,
				width : dialogWidth,
				close: function() {
					$(this).remove();
					GUI.blockKeyEvents = false;
				}
			});
			
			
		};
	




		$(function() {
			window.setTimeout(function() {

				GUI.adjustContent();

				GUI.setupInspector();

			}, 100);
		});
		
		
		
		
		/* keydown events */
		$(function() {
			
			$(document).bind("keydown", function(event) {
				
				if ($("input:focus,textarea:focus").get(0) == undefined && GUI.blockKeyEvents != true) {
				
					if (event.which == 8 || event.which == 46) {

						event.preventDefault();

						/* delete selected objects */
						$.each(ObjectManager.getSelected(), function(key, object) {

							if ($(object.getRepresentation()).data("jActionsheet")) {
								$(object.getRepresentation()).data("jActionsheet").remove();
							}

							object.deleteIt();

						});
					}
					
				}
				
			});
			
		});
                
                var backupMouseCoord = new Array(2); // for moving workspace
                
                // bind mid mouse to moving workspace
                function mouseDownEvent(event) {
                
                        return true; // TODO enable again
                        // TODO BUG doesn't work in firefox
                        console.log('mouseDownEvent');
                        
                        var event = window.event;
                        console.log(event);
                        
                        if (event.which == null) {  // IE case
                            if (event.button == 4) { // not middle button
                                console.log('   mid button');
                                initWorkspaceMove();
                            }
                        } else {                    // others
                            if (event.which == 2) { // not middle button
                                console.log('   mid button');
                                initWorkspaceMove();
                            }
                        }
                        
                        return true;
                }
                
                // make calculations for workspace movement
                function initWorkspaceMove() {
                    backupMouseCoordinates();
                    
                    // has workspace been moved already?
                    svg = document.getElementsByTagName('svg')[0];
                    if (svg.getAttribute('style') != null) {
                        // regard old movements by parsing the margin
                        var style = svg.getAttribute('style')
                        var match = style.match(
                            /margin\-(left|top):([\-]?\d*);/g
                        );
                        var margin = [
                             parseInt(match[0].substr(match[0].search(/:/)+1)),
                             parseInt(match[1].substr(match[1].search(/:/)+1))
                        ];
                            
                        // correct the origin
                        backupMouseCoord[0] -= margin[0];
                        backupMouseCoord[1] -= margin[1];
                    }
                    
                    // start listen to movement
                    document.body.onmousemove = moveWorkspace;
                    document.body.style.cursor = 'move';
                }
                
                // move svg relative to mouse
                function moveWorkspace()
                {
                    // transformation
                    var distance = [
                        event.screenX - backupMouseCoord[0],
                        event.screenY - backupMouseCoord[1]
                    ];
                    
                    // move by changing the margin
                    var svg = document.getElementsByTagName('svg')[0];
                    svg.setAttribute('style',
                        'margin-left:'+distance[0]+';'
                        +'margin-top:'+distance[1]+';'
                    );
                }
                
                function backupMouseCoordinates() {
                    backupMouseCoord = [event.screenX, event.screenY];
                }
                
                function mouseUpEvent() {
                    // quit moving workspace
                    document.body.onmousemove = '';
                    document.body.style.cursor = 'auto';
                    mouseDownOld = new Array(2);
                    
                    return true;
                }
	
	</script>
</head>
<body onmousedown="mouseDownEvent();" onmouseup="mouseUpEvent();">
	
	<div id="header">
		
		<div class="header_right">
			
		</div>
		
		<div class="header_left">
		
		</div>
		
	</div>


	<div id="content"></div>
	
	
	<div id="inspector">
		
	</div>
	
	<div id="actionsheet"></div>
	
	<div id="error_bg"></div>
	<div id="error_box">
		
		<div id="error_box_heading"></div>
		<div id="error_box_message"></div>
		<div id="error_box_button"></div>
		
	</div>

</body>
</html>
