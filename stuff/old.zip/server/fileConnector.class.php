<?php

require_once('abstractConnector.class.php');

class FileConnector extends AbstractConnector{
	
	const DATA_PATH='../../../data/';    // This must be specified elsewhere
	
	public function __construct(){
		$this->input['command']='info';
		$this->input['room']=false;
		$this->input['id']=false;
		$this->input['data']=false;
		$that=$this;
		$this->registerCommand('info',function() use($that) {$that::response('This is the file connector.');});
	}
	
	public function getContentAge($room,$id){

		// as this is file specific code, it should not be here.
		
		$contentPath=$this::DATA_PATH.$room.'/'.$id.'.content';
				
		if (file_exists($contentPath)) return filectime($contentPath); else return 0;
	}
	
	public function create($room, $type){
		$id=round((microtime(true)*10000)-12960832132043);    // Create an increasing id
		return $id;
	}
	
	public function get($room, $id, $key){
		
		if ($key == "content" AND !$this->getUserRight($room, $id, "read_content")) {
			$this->error(self::ERROR_NO_READ_RIGHT,'No right to read content on '.$id.' ('.$room.').');
			return false;
		}
		
		if ($key == "object" AND !$this->getUserRight($room, $id, "read_attributes")) {
			$this->error(self::ERROR_NO_READ_RIGHT,'No right to read attributes on '.$id.' ('.$room.').');
			return false;
		}
		
		if ($key=='object') $key='object.txt';
		
		$roomPath=self::DATA_PATH.$room;
		
		$filePath=$roomPath.'/'.$id.'.'.$key;
		
		if (!file_exists($filePath)) return false;
		
		$obj=file_get_contents($filePath);
		
		return $obj;
		
	}
	
	public function set($room, $id, $key, $value){
		
		if ($key == "content" AND !$this->getUserRight($room, $id, "change_content")) {
			$this->error(self::ERROR_NO_WRITE_RIGHT,'No right to write content on '.$id.' ('.$room.').');
			return false;
		}
		
		if ($key == "object" AND !$this->getUserRight($room, $id, "change_attributes")) {
			$this->error(self::ERROR_NO_WRITE_RIGHT,'No right to write attributes on '.$id.' ('.$room.').');
			return false;
		}

		
		if ($key=='object') $key='object.txt';
		
		$roomPath=self::DATA_PATH.$room;

		if (!file_exists($roomPath)) @mkdir($roomPath);
		
		if (!file_exists($roomPath)) {
			$this->error(self::ERROR_NO_CREATE_RIGHT,'Could not create the room ('.$room.').');
			return false;
		}
		
		$filePath=$roomPath.'/'.$id.'.'.$key;
		
		if ($key=='object.txt') {
			$newData=json_decode($value,true);
			$oldData=json_decode($this->get($room,$id,$key),true);
			foreach ($newData as $k=>$v){
				$oldData[$k]=$v;
			}
			$value=json_encode($oldData);
		}
		
		if (!file_put_contents($filePath,$value)) {
			$this->error(self::ERROR_NO_WRITE_RIGHT,'Cannot write the object file ('.$id.').');
			return false;
		};
		return true;
		
	}
	
    public function delete($room, $id){
    	logToFile('delete',"Deleting $id in $room");
    	$roomPath=self::DATA_PATH.$room;
		if (file_exists($roomPath.'/'.$id.'.object.txt')){
			unlink($roomPath.'/'.$id.'.object.txt');
			if (file_exists($roomPath.'/'.$id.'.object.txt')) $this->error(0,'File is still there.');
		}
		if (file_exists($roomPath.'/'.$id.'.content')) unlink($roomPath.'/'.$id.'.content');
    }

	public function load($room){
		
		if ($room == "uninitialized") {
			$room = $this->getHomeroom();
		}
		
		$roomPath=self::DATA_PATH.$room;
		
		if (!file_exists($roomPath)) {
			@mkdir($roomPath);
		}
		
		if (!file_exists($roomPath)) {$this->error(self::ERROR_MISSING_ROOM,'Room does not exist!');}
		
		$objects=array();
		$roomObject=array();
		
		if (isset($roomPath)){

			$files=scandir($roomPath);
		
			foreach ($files as $file){
				if (strpos($file,'.object.txt')){
					$obj=file_get_contents($roomPath.'/'.$file);
					$obj=json_decode($obj,true);
					$id=str_replace('.object.txt','',$file);
					$obj['id']=$id;      //Override the id with the id saved in the filename
					
					$rights = $this->getUserRights($room, $id);
					
					if ($this->getUserRight($room, $id, "read_attributes")) {
					
						$obj['contentAge']=$this->getContentAge($room,$id);

						$obj['rights']=$rights;

						if ($id==$room) {
							$roomObject=$obj;
						} else {
							$objects[]=$obj;
						}
					
					}
					
				}
			}
		}
		
		$roomObject['id']=$room;
		
		$roomObject['rights']=$this->getUserRights($room);
		
		$roomObject['type']='Room';
		
		$result=array();
		
		$result['inventory']=$objects;
		$result['room']=$roomObject;
		
		return $result;
	}
	
	
	
	public function getUserRight($room, $objectId, $name)
	{
		$rights = $this->getUserRights($room, $objectId);
		if (isset($rights[$name])) {
			return $rights[$name];
		} else return false;
	}
	
	public function getUserRights($room, $objectId=false)
	{
		$room = strtolower($room);
		
		/* temp */
		if (isset($_SESSION['rights'][$room])) {
			$rights = $_SESSION['rights'][$room];
		} else {
			$rights = Array(
				"change_attributes" => true,
				"read_attributes" => true,
				"change_content" => true,
				"read_content" => true,
				"evaluate" => true
			);
		}
		
		/*
		ob_start(); 

		if (isset($_SESSION['rights'][$room])) {
			var_dump($_SESSION['rights'][$room]);			
		} else {
			echo $room.' not set'."\n";
			var_dump($_SESSION);
		}
		 
		$var_dump = ob_get_contents(); 
		ob_end_clean();
		
		$fp = fopen('error.log', 'w');
		fwrite($fp, time()."\n".$var_dump."\n");
		fclose($fp);
		*/

		//$this->error(self::ERROR_NO_WRITE_RIGHT,'room: '.$room.', '.print_r($rights, true));
		
		return $rights;
		
	}
	
	public function getHomeroom()
	{
		return $_SESSION['homeroom'];
	}
	
	public function getUsername()
	{
		return $_SESSION['username'];
	}
	
}

?>