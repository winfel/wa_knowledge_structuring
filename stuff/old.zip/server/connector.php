<?php

	session_name("webarena");
	session_start();

 ini_set ('error_reporting', E_ALL);
 ini_set ('html_errors', 'Off');
 
 set_error_handler("logError");
 

require_once('fileConnector.class.php');

$connector=new FileConnector();

$cwd= (getcwd());
$objectsFolder='../arena/objects';

$objectsDir=$cwd.'/'.$objectsFolder;

$temp=scandir($objectsDir);unset($temp[0]);unset($temp[1]);

$objects=array();

$n=0;
foreach ($temp as $object){
	$n++;
	if ($object[0]=='.') continue;      // Do not care about .svn etc.
	$data=explode('.',$object);
	if (!isset($data[1])) continue;
	$index=$data[0]*1000+$n;
	$objects[$index]=$object;
}

ksort($objects);

foreach ($objects as $object){
    $data=explode('.',$object);
	$objectName=$data[1];

	if (!isset($object[1])) continue;
	$objectFolder=$objectsFolder.'/'.$object;
	$objectPath=$cwd.'/'.$objectFolder;
	$files=scandir($objectPath);
	foreach ($files as $file){
		if (!stripos($file,'.php')) continue;
		include($objectFolder.'/'.$file);   // TODO ERROR checking
	}
}

$connector->parseInput();

function logError($errno, $errstr, $errfile, $errline){
	$fp = fopen('error.log', 'a');
	fwrite($fp, time()."\n$errstr in $errfile line $errline\n");
	fclose($fp);
	die ('SERVER ERROR');
}

?>