<?php

class sharepoint {
	private $socket;
	private $host;
	private $username;
	private $password;
	public $context;
	
	function __construct($host, $username, $password) {
		$this->host = $host;
		$this->username = $username;
		$this->password = $password;
		$this->context = stream_context_create(array('http' => array('header'  => "Authorization: Basic " .base64_encode($this->username .':' .$this->password))));
	}
	
	private function open() {
		$this->socket = fsockopen("ssl://{$this->host}", 443, $errno, $errstr, 10);
	}
	
	private function close() {
		fclose($this->socket);
	}
	
	private function request($header) {
		$result = '';
		fwrite($this->socket, $header);
		while (!feof($this->socket)) {
			$result .= fgets($this->socket, 1024);
		}
		return $result;
	}
	
	private function common_header() {
		$auth = base64_encode($this->username .':' .$this->password);
		$header = "Authorization: Basic {$auth}\r\n";
		$header .= "Host: {$this->host}\r\n";
	    $header .= "Connection:close\r\n";
        return $header;
	}
	
	function propfind($path, $depth = 1) {
		$this->open();
		
		$path = str_replace("%2F", "/", rawurlencode(html_entity_decode($path, ENT_NOQUOTES, 'UTF-8')));
		
		$content = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n";
		$content .= "<D:propfind xmlns:D=\"DAV:\">\r\n";
		$content .= "<D:allprop/>\r\n";
		$content .= "</D:propfind>";
		
		$header = "PROPFIND {$path} HTTP/1.1\r\n";
		$header .= $this->common_header();
		$header .= "Content-Type: text/xml\r\n";
		$header .= "Content-Length: " .strlen($content) ."\r\n";
		$header .= "Depth: {$depth}\r\n";
		$header .= "\r\n";
		
		$result = $this->request($header .$content);
		$this->close();
		
		$status = substr($result, 0, strpos($result, "\r\n"));
		if (strpos($status, "HTTP/1.1 20") === false) {
			throw new Exception($status); 
		} else {
			$result = str_replace("</D:", "</", str_replace("<D:", "<", substr($result, strpos($result, "\r\n\r\n") + 4)));
			return $result;
		}
	}
	
	function mkcol($path) {
		$this->open();
		
		$path = str_replace("%2F", "/", rawurlencode(html_entity_decode($path, ENT_NOQUOTES, 'UTF-8')));
		
		$header = "MKCOL {$path} HTTP/1.1\r\n";
		$header .= $this->common_header();
		$header .= "Content-Length: 0\r\n";
		$header .= "\r\n";
		
		$result = $this->request($header);
		$this->close();

		$status = substr($result, 0, strpos($result, "\r\n"));
		if (strpos($status, "HTTP/1.1 20") === false) {
			throw new Exception($status); 
		} else {
			return true;
		}
	}
	
	function copy($path, $destination, $overwrite = false) {
		$this->open();
		
		$path = str_replace("%2F", "/", rawurlencode(html_entity_decode($path, ENT_NOQUOTES, 'UTF-8')));
		$destination = str_replace("%2F", "/", rawurlencode(html_entity_decode($destination, ENT_NOQUOTES, 'UTF-8')));
		
		$header = "COPY {$path} HTTP/1.1\r\n";
		$header .= $this->common_header();
		$header .= "Content-Length: 0\r\n";
		if ($overwrite) {
			$header .= "Overwrite: T\r\n";
		} else {
			$header .= "Overwrite: F\r\n";
		}
		$header .= "Destination: https://{$this->host}{$destination}\r\n";
		$header .= "\r\n";
		
		$result = $this->request($header);
		$this->close();
		
		$status = substr($result, 0, strpos($result, "\r\n"));
		if (strpos($status, "HTTP/1.1 20") === false) {
			throw new Exception($status); 
		} else {
			return true;
		}
	}
	
	function move($path, $destination, $overwrite = false) {
		$this->open();
		
		$path = str_replace("%2F", "/", rawurlencode(html_entity_decode($path, ENT_NOQUOTES, 'UTF-8')));
		$destination = str_replace("%2F", "/", rawurlencode(html_entity_decode($destination, ENT_NOQUOTES, 'UTF-8')));
		
		$header = "MOVE {$path} HTTP/1.1\r\n";
		$header .= $this->common_header();
		$header .= "Content-Length: 0\r\n";
		if ($overwrite) {
			$header .= "Overwrite: T\r\n";
		} else {
			$header .= "Overwrite: F\r\n";
		}
		$header .= "Destination: https://{$this->host}{$destination}\r\n";
		$header .= "\r\n";
		
		$result = $this->request($header);
		$this->close();
		
		$status = substr($result, 0, strpos($result, "\r\n"));
		if (strpos($status, "HTTP/1.1 20") === false) {
			throw new Exception($status); 
		} else {
			return true;
		}
	}
	
	function delete($path) {
		$this->open();
		
		$path = str_replace("%2F", "/", rawurlencode(html_entity_decode($path, ENT_NOQUOTES, 'UTF-8')));
		
		$header = "DELETE {$path} HTTP/1.1\r\n";
		$header .= $this->common_header();
		$header .= "Content-Length: 0\r\n";
		$header .= "\r\n";
		
		$result = $this->request($header);
		$this->close();
		
		$status = substr($result, 0, strpos($result, "\r\n"));
		if (strpos($status, "HTTP/1.1 20") === false) {
			throw new Exception($status); 
		} else {
			return true;
		}
	}
	
	function put($path, $binarydata) {
		$this->open();
		
		$path = str_replace("%2F", "/", rawurlencode(html_entity_decode($path, ENT_NOQUOTES, 'UTF-8')));		
		$content = $binarydata;
		
		$header = "PUT {$path} HTTP/1.1\r\n";
		$header .= $this->common_header();
		$header .= "Content-Type: application/octet-stream; charset=utf-8\r\n";
		$header .= "Content-Length: " .strlen($content) ."\r\n";
		$header .= "\r\n";
		
		$result = $this->request($header .$content);
		$this->close();
				
		$status = substr($result, 0, strpos($result, "\r\n"));
		if (strpos($status, "HTTP/1.1 20") === false) {
			throw new Exception($status); 
		} else {
			return true;
		}
	}
	
	function get($path) {
		return file_get_contents("https://{$this->host}{$path}", false, $this->context);
	}
	
	function get_files_from_xml($xml) {
		$parser = new SimpleXMLElement($xml);
		foreach ($parser->response as $response) {
			echo $response->propstat->prop->displayname ."\r\n";
		}
	}
	
}

//$sharepoint->get_files_from_xml($sharepoint->propfind("/websites/studiolo/studiolo"));

//echo $sharepoint->get("/websites/studiolo/studiolo/studiolo.png");

//echo $sharepoint->copy("/websites/studiolo/studiolo/studiolo.png", "/websites/studiolo/studiolo/test/studiolo.png");

//$filedata = file_get_contents("/Users/oberhoff/Projekte/studiolo/dokumente/studiolo.png");
//echo $sharepoint->put("/websites/studiolo/studiolo/studiolo.png", $filedata);


?>