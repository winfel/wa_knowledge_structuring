<?php
include "sharepoint.class.php";

$sharepoint = new sharepoint("projects.uni-paderborn.de", "oberhoff", base64_decode('NZ==') . base64_decode('bg==') . base64_decode('KT==') .base64_decode('TW==') . base64_decode('TD==') . base64_decode('bg==') . base64_decode('YQ==') . base64_decode('MQ=='));
$content = null;
if (isset($_REQUEST["name"])) {
	$content = $sharepoint->get("/websites/studiolo/studiolo/webarena/" .$_REQUEST["name"]);
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename="' .$_REQUEST["name"] .'"');
	echo $content;
}

?>