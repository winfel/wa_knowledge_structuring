<?php
include "easydb.class.php";

$easy = new easydb();
$image_url = null;
if (isset($_REQUEST["id"])) {
	$image_url = $easy->get_image_url($_REQUEST["id"], 1000);
	echo file_get_contents($image_url, false, $easy->context);
}

?>