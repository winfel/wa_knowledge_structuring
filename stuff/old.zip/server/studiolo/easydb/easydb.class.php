<?php

class easydb {
	public $context;
	private $sql;
	private $url_object_search;
	private $url_object_html;
	private $url_object_retrieve_bulk;

	function __construct() {
		$this->context = stream_context_create(array('http' => array('header'  => "Authorization: Basic c3lzdGVtX3N0dWRpb2xvOkNhODRfMjk3Qmw=")));
		$this->sql = "SELECT * FROM Bilder WHERE titel LIKE '%:KEYWORD:%' OR kommentar LIKE '%:KEYWORD:%'";
		$this->url_object_search = 			"https://easydb.uni-paderborn.de/easy/fs.php?output=serialized&function=object_search&sql=:SQL:";
		$this->url_object_retrieve_bulk = 	"https://easydb.uni-paderborn.de/easy/fs.php?output=serialized&function=object_retrieve_bulk&table_name=Bilder&image_size=:IMAGE_SIZE:&download_size=1024&ids=:IDS:";
		$this->url_object_html = 			"https://easydb.uni-paderborn.de/easy/fs.php?output=serialized&function=object_html&table_name=Bilder&view=standard&ids=:IDS:";
	}

	// EasyDB API Functions
	function object_search($keyword) {
		$sql = str_replace(":KEYWORD:", $keyword, $this->sql);
		$url = str_replace(":SQL:", urlencode($sql), $this->url_object_search);
		$data = file_get_contents($url, false, $this->context);
		$data_array = unserialize($data);
		if (count($data_array["response"]["data"]) < 1) {
			return null;
		}
		return $data_array;
	}

	function object_retrieve_bulk($ids, $image_size) {
		if (is_array($ids)) {
			$ids_string = implode(",", $ids);
		} else {
			$ids_string = $ids;
		}
		$url = $this->url_object_retrieve_bulk;
		$url = str_replace(":IDS:", $ids_string, $url);
		$url = str_replace(":IMAGE_SIZE:", $image_size, $url);
		$data = file_get_contents($url, false, $this->context);
		$data_array = unserialize($data);
		if (count($data_array["response"]["objects"]) < 1) {
			return null;
		}
		return $data_array;
	}

	function object_html($ids) {
		if (is_array($ids)) {
			$ids_string = implode(",", $ids);
		} else {
			$ids_string = $ids;
		}
		$url = $this->url_object_html;
		$url = str_replace(":IDS:", $ids_string, $url);
		$data = file_get_contents($url, false, $this->context);
		$data_array = unserialize($data);
		return $data_array;
	}

	// EasyDB Extended Functions
	function get_image_urls_from_search_array($search_array, $image_size) {
		if ($search_array == null) {
			return null;
		}
		$ids = array();
		foreach ($search_array["response"]["data"] as $value) {
			$ids[] = $value["id"];
		}
		$data_array = $this->object_retrieve_bulk(implode(",", $ids), $image_size);
		$id_url = array();
		foreach ($data_array["response"]["objects"] as $value) {
			if (!array_key_exists("error", $value)) {
				$id_url[$value["data"]["id"]] = $value["data"]["bild.image"]["remote_uri"];
			} else {
				$id_url[$value["data"]["id"]] = null;
			}
		}
		return $id_url;
	}

	function get_image_url($ids, $image_size) {
		$data_array = $this->object_retrieve_bulk($ids, $image_size);
		if ($data_array == null) {
			return null;
		}
		if (count($data_array["response"]["objects"]) == 1){
			return $data_array["response"]["objects"]["0"]["data"]["bild.image"]["remote_uri"];
		} else {
			$urls_array = array();
			foreach ($data_array["response"]["objects"] as $value) {
				if (!array_key_exists("error", $value)) {
					$urls_array[] = $value["data"]["bild.image"]["remote_uri"];
				} else {
					$urls_array[] = null;
				}
			}
			return $urls_array;
		}
	}

}

?>