<?php
include "easydb.class.php";

$easy = new easydb();
$search_array = null;
if (isset($_REQUEST["keyword"]) && $_REQUEST["keyword"] != "") {
	$search_array = $easy->object_search($_REQUEST["keyword"]);
	$images_id_url_120 = $easy->get_image_urls_from_search_array($search_array, 120);
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>EasyDB Search</title>
</head>
<body>
<script>
top.document.getElementById('progress').style.visibility='hidden';
function setID(id){
	top.document.getElementById('reference').value=id;
	top.Helper.ele('dialogSave').onclick();
}
</script>
<?php
if (is_array($search_array)) {
	foreach ($search_array["response"]["data"] as $value) { ?>
<table width="100%" border="0">
	<tr>
		<td width="125px"><img
			src="<?php echo $images_id_url_120[$value["id"]]; ?>" onclick="setID(<?php echo $value["id"]; ?>);" style="cursor: pointer"/></td>
		<td><?php echo $value["id"]; ?><br />
		<b><?php echo $value["titel"]; ?></b><br />
		<?php echo $value["kommentar"]; ?></td>
	</tr>
</table>
<hr />
<?php }
} ?>
</body>
</html>
