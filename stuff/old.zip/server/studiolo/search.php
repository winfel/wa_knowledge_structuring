<!DOCTYPE html>
<html>
<head>
</head>
<body>
<h1>Dies ist die Suche</h1>

<span onclick="setID(5);">ID 5</span>
<span onclick="setID(9);">ID 9</span>

<script>

function setID(id){
	top.document.getElementById('reference').value=id;
	top.Helper.ele('dialogSave').onclick();				// Improve when widget is implemented!
}

</script>
</body>
</html>