<?php

/**
*
*	Abstract data connector for WebArena
*
*	This class defines constants and general functions for
*   data connectors. Actual connectors need to implement
*   this class.
*
*	Connectors only provide very basic functions for data
*   access on a low level. Server functionality is provided
*   by the objects themselves and registred on the connector.
*	
*   @author Felix Winkelnkemper, University of Paderborn, 2011
*
**/

abstract class AbstractConnector {
	
	//Errors for command input
	
	const ERROR_WRONG_COMMAND=1;
	const ERROR_MISSING_ROOM=2;
	const ERROR_MISSING_ID=3;
	const ERROR_MISSING_DATA=4;
	
	//Errors for rights
	
	const ERROR_NO_CREATE_RIGHT=5;
	const ERROR_NO_WRITE_RIGHT=6;
	const ERROR_NO_READ_RIGHT=10;
	
	const ERROR_MISSING_CONTENT=7;
	const ERROR_UPLOAD_FAILED=8;
	
	const ERROR_NOT_EXISTING=9;
	
	private $input=array();
	
	private $user=array();
	
	public function __construct(){
		$this->input['command']='info';
		$this->input['room']=false;
		$this->input['id']=false;
		$this->input['data']=false;
	}
	
	/*
	*  INPUT DATA
	*
	*	each call to the connector calls a command. The command name
	* 	and corresponding data are provided by GET or POST. This
	* 	information can be provided:
	*
	*	command: the command name (String)
	*	room: the room the command works on (String)
	*	id: the id of the object the command works on (String)
	*	data: additional data for the command (JSON-Encoded data)
	*
	*/
	
	public function getCommand(){return $this->input['command'];}
	public function getRoom(){return $this->input['room'];}
	public function getID(){return $this->input['id'];}
	public function getData(){return $this->input['data'];}
	
	/*
	*	read the provided data from GET or POST and execute the specified command.
	*/
	public function parseInput(){
		$req=$_REQUEST;
		logRequest($_REQUEST);
		
		if (isset($req['command'])) $this->input['command']=$req['command'];
		if (isset($req['room'])) $this->input['room']=self::secure($req['room']);
		if (isset($req['id'])) $this->input['id']=self::secure($req['id']);
		if (isset($req['data'])) $this->input['data']=self::asArray($req['data']);
		
		$this->executeCommand($this->input['command']); break;
	}
	
	/*
	*	COMMAND REGISTRATION
	*
	*
	*	commands are registred on the connector in a javascript
	*   like way using closures. They are registred using the
	*   registerCommand function and have access to public connector
	*   functions.
	*
	*	Example (a command the simply echos the provided data):
	*
	*   // assume that $connector is a valid connector of this class
	*
	*	$connector->registerCommand('echoData',function() use ($connector) {
	*		//the connector is available in here as $connector;
	*
	*		$data=$connector->get('data');
	*		$connector->response(json_encode($data)); 
	*	});
	*
	*/
	
	private $commandArray=array();
	
	/*
	*	register a command (see example above). If a command yet has been registred,
	*   it is overwritten.
	*/
	public function registerCommand($name,$function){	
		$this->commandArray[$name]=$function;	
	}
	
	public function unregisterCommand($name){	
		if ($this->hasCommand($name)) unset($this->commandArray[$name]);	
	}
	
	public function hasCommand($name){	
		return isset($this->commandArray[$name]);
	}
	
	/*
	*	execute the registred function
	*/
	public function executeCommand($name){
		
		if (!$this->hasCommand($name)) $this->error (self::ERROR_WRONG_COMMAND,'Command does not exist');
		
		try {
			return $this->commandArray[$name]();
		} catch (Exception $e) {
			$this->error (self::ERROR_WRONG_COMMAND,'Command does not behave well');
		}
		
	}
	
	/*
	*	get the function that is registred for the command. This is necessariy
	*	if the function should be overridden and the overriding function
	*	wants to access the old function.
	*/
	public function getCommandFunction($name){
		if ($this->hasCommand($name)) {
			return $this->commandArray[$name];
		}
		return false;
	}
	
	/*
	*	ATTRIBUTE ACCESS
	*	
	*	helper functions providing access to an object's attributes
	*	or a single object.
	*/
	
	private $attributes=array();
	public function getAttributes($room,$id){
		if (isset($this->attributes[$room.'.'.$id])) return $this->attributes[$room.'.'.$id];
		$attr=$this->asArray($this->get($room,$id,'object'));
		$this->attributes[$room.'.'.$id]=$attr;
		return $attr;
	}
	
	public function getAttribute($room,$id,$attribute){
		$attributes=$this->getAttributes($room,$id);
		if (!isset($attributes[$attribute])) return false;
	    return $attributes[$attribute];
	}
	
	public function setAttibute($room,$id,$attribute,$value){
		$attributes=$this->getAttributes($room,$id);
		$attributes[$attribute]=$value;
		$this->set($room,$id,'object',json_encode($attributes));
	}
	

	
	/*
	*	LOW LEVEL DATA ACCESS	
	*
	*	these are the basic level functions each connector has to
	*	implement. They describe data access on a filesystem, database
	*   or server level. No object should ever have to care about these
	*	technical details.
	*/
	
	abstract public function get($room,$id, $key);
	abstract public function set($room,$id, $key, $value);
	abstract public function delete($room,$id);
	abstract public function create($room,$type); //returns id
	abstract public function load($room);
	
	/*
	*	RESPONSE FUNCTIONS
	*
	*	there are two different ways a command can respond. Either, there is
	*	a technically valid response, which the client should handle normally
	*	or there is an error, which has to be dealt with in other ways.
	*/
	
	public static function error($code,$message){
		die ("ERROR\n$code\n".$message);
	}
	
	public static function response($object){
		die ("RESPONSE\n".json_encode($object));
	}	
	
	/*
	*	Internal functions for conveiniance and security
	*/
	
	private static function secure($input){
		$output=trim($input);
		$output=str_replace("\n",'',$output);
		$output=str_replace("\r",'',$output);
		$output=str_replace('\\','',$output);
		$output=str_replace("/",'',$output);
		$output=str_replace("\0",'',$output);
		
		return $output;
	}
	
	private static function asArray($input){
		$result=(json_decode($input,true));
		
		if ($result) return $result;
		
		return json_decode(stripslashes($input),true);
	}
	
}

function logRequest($request){
	logToFile('request',$request);
}

function logToFile($file,$data){
	return;
	$data=var_export($data,true);
	$fp = fopen($file.'.log', 'a');
	fwrite($fp, time()."\n$data\n-----------\n");
	fclose($fp);
}

?>